// おとけい 追加ツール（コンプ・EQ・アンプ・音圧・ラウドネス・歌のキー合わせ・ループBPM・コピー）
(function () {
  "use strict";
  const K = window.OTK;
  if (!K) return;
  const { $, num, fmt, ok, on, SHARP, nameOf, T, LANG } = K;

  // ---------- コンプレッサー ----------
  function comp() {
    const th = $("cp-th");
    if (!th) return;
    const ra = $("cp-ratio"), inp = $("cp-in"), mk = $("cp-makeup"), knee = $("cp-knee");
    const out = (x, T, R, W) => {
      // ソフトニー（幅W dB）にも対応した一般的な式
      if (W > 0 && 2 * (x - T) > -W && 2 * (x - T) < W) {
        return x + (1 / R - 1) * Math.pow(x - T + W / 2, 2) / (2 * W);
      }
      return x <= T ? x : T + (x - T) / R;
    };
    const render = () => {
      const Th = num(th), R = ra.value === "inf" ? 1e9 : num(ra), x = num(inp), M = num(mk) || 0, W = num(knee) || 0;
      if (!ok(Th, -80, 0) || !(R >= 1) || !ok(x, -80, 20)) { $("cp-gr").textContent = "—"; return; }
      const y = out(x, Th, R, W);
      $("cp-gr").textContent = fmt(x - y, 1);
      $("cp-out").textContent = fmt(y + M, 1);
      // グラフ：入力 −60〜0dB を横軸、出力を縦軸
      const X = (v) => (v + 60) / 60 * 260 + 30, Y = (v) => 270 - (v + 60) / 60 * 260;
      let d = "";
      for (let v = -60; v <= 0.001; v += 0.5) d += `${d ? "L" : "M"}${X(v).toFixed(1)} ${Y(Math.max(-60, Math.min(12, out(v, Th, R, W) + M))).toFixed(1)} `;
      $("cp-curve").setAttribute("d", d);
      const px = Math.max(-60, Math.min(0, x));
      $("cp-dot").setAttribute("cx", X(px)); $("cp-dot").setAttribute("cy", Y(Math.max(-60, Math.min(12, out(px, Th, R, W) + M))));
      $("cp-thline").setAttribute("x1", X(Th)); $("cp-thline").setAttribute("x2", X(Th));
    };
    on([th, inp, mk, knee], "input", render); ra.addEventListener("change", render);
    K.stepper(th, render); K.stepper(inp, render);
    render();
  }

  // ---------- EQのQと帯域幅 ----------
  const qToOct = (q) => 2 / Math.LN2 * Math.asinh(1 / (2 * q));
  const octToQ = (n) => Math.sqrt(Math.pow(2, n)) / (Math.pow(2, n) - 1);
  function eqq() {
    const q = $("eq-q");
    if (!q) return;
    const fc = $("eq-fc"), oct = $("eq-oct");
    const draw = (Q, f) => {
      // ベル型の山を、対数の周波数軸（20Hz〜20kHz）で描く
      const X = (hz) => Math.log10(hz / 20) / 3 * 560 + 20;
      let d = "";
      for (let i = 0; i <= 300; i++) {
        const hz = 20 * Math.pow(1000, i / 300);
        const r = hz / f, g = 1 / Math.sqrt(1 + Q * Q * Math.pow(r - 1 / r, 2)); // 帯域通過の形（目安）
        d += `${i ? "L" : "M"}${X(hz).toFixed(1)} ${(110 - g * 90).toFixed(1)} `;
      }
      $("eq-curve").setAttribute("d", d);
      const s = Math.sqrt(1 + 1 / (4 * Q * Q)), lo = f * (s - 1 / (2 * Q)), hi = f * (s + 1 / (2 * Q));
      $("eq-band").setAttribute("x", X(lo)); $("eq-band").setAttribute("width", Math.max(1, X(hi) - X(lo)));
      return [lo, hi];
    };
    const fromQ = (keepOct) => {
      const Q = num(q), f = num(fc);
      if (!(Q > 0) || !(f > 0)) return;
      const n = keepOct === true ? num(oct) : qToOct(Q);
      if (keepOct !== true) oct.value = n.toFixed(2);
      const [lo, hi] = draw(Q, f);
      $("eq-range").textContent = T("eq.range", { lo: fmt(lo, lo < 100 ? 1 : 0), hi: fmt(hi, hi < 100 ? 1 : 0) });
      $("eq-oct-out").textContent = fmt(n, 2);
    };
    const fromOct = () => {
      const n = num(oct);
      if (!(n > 0)) return;
      q.value = octToQ(n).toFixed(2);
      fromQ(true); // 打っている途中のオクターブの値は書きかえない
    };
    on([q, fc], "input", () => fromQ()); oct.addEventListener("input", fromOct);
    document.querySelectorAll("[data-q]").forEach((b) => b.addEventListener("click", () => { q.value = b.dataset.q; fromQ(); }));
    fromQ();
  }

  // ---------- アンプの出力と電圧 ----------
  function amp() {
    const w = $("ap-w");
    if (!w) return;
    const r = $("ap-ohm"), v = $("ap-v"), r2 = $("ap-ohm2");
    const r1 = () => {
      const P = num(w), R = num(r);
      if (!(P > 0) || !(R > 0)) { $("ap-volt").textContent = "—"; $("ap-amp").textContent = "—"; return; }
      const V = Math.sqrt(P * R);
      $("ap-volt").textContent = fmt(V, 1);
      $("ap-amp").textContent = fmt(V / R, 2);
    };
    const rr = () => {
      const V = num(v), R = num(r2);
      $("ap-watt").textContent = (V > 0 && R > 0) ? fmt(V * V / R, 1) : "—";
    };
    on([w, r], "input", r1); r.addEventListener("change", r1);
    on([v, r2], "input", rr); r2.addEventListener("change", rr);
    r1(); rr();
  }

  // ---------- スピーカーの音圧 ----------
  function spl() {
    const s = $("sp-sens");
    if (!s) return;
    const w = $("sp-w"), d = $("sp-d");
    const render = () => {
      const S = num(s), P = num(w), D = num(d);
      if (!isFinite(S) || !(P > 0) || !(D > 0)) { $("sp-out").textContent = "—"; return; }
      const L = S + 10 * Math.log10(P) - 20 * Math.log10(D);
      $("sp-out").textContent = fmt(L, 1);
      $("sp-1m").textContent = fmt(S + 10 * Math.log10(P), 1);
      // 身近な音とくらべる（よく使われるおおよその目安）
      const ref = [60, 70, 80, 90, 100, 110, 120].map((x) => [x, T("spl.r" + x)]);
      const hit = ref.reduce((a, r) => (Math.abs(r[0] - L) < Math.abs(a[0] - L) ? r : a));
      $("sp-like").textContent = L < 50 ? T("spl.quiet") : T("spl.about", { x: hit[1] });
    };
    on([s, w, d], "input", render);
    render();
  }

  // ---------- ラウドネスの差 ----------
  function loud() {
    const now = $("ld-now");
    if (!now) return;
    const render = () => {
      const L = num(now);
      document.querySelectorAll("[data-target]").forEach((td) => {
        const t = parseFloat(td.dataset.target);
        if (!isFinite(L)) { td.textContent = "—"; return; }
        const g = t - L;
        td.textContent = Math.abs(g) < 0.05 ? T("tr.same") : `${g > 0 ? "+" : "−"}${fmt(Math.abs(g), 1)} dB`;
        td.classList.toggle("down", g < 0);
      });
    };
    now.addEventListener("input", render); K.stepper(now, render);
    render();
  }

  // ---------- 歌のキー合わせ ----------
  // カラオケ表記：A で区切る（hiA ＝ A4 ＝ 440Hz、mid2C ＝ C4）
  const ZONES = ["lowlow", "low", "mid1", "mid2", "hi", "hihi", "hihihi"];
  // カラオケ表記は日本だけのもの。ほかの言語では国際式（A4など）を使う
  const karaoke = (m) => (LANG === "ja" ? ZONES[Math.floor((m - 21) / 12)] + SHARP[m % 12] : nameOf(m));
  const noteLabel = (m) => (LANG === "ja" ? T("paren", { a: karaoke(m), b: nameOf(m) }) : nameOf(m));
  K.karaoke = karaoke; K.noteLabel = noteLabel;
  function keyrange() {
    const ids = ["kr-my-hi", "kr-song-hi", "kr-my-lo", "kr-song-lo"];
    if (!$(ids[0])) return;
    const opts = [];
    for (let m = 33; m <= 93; m++) opts.push(`<option value="${m}">${noteLabel(m)}</option>`);
    const defaults = { "kr-my-hi": 67, "kr-song-hi": 71, "kr-my-lo": 45, "kr-song-lo": 50 };
    ids.forEach((id) => {
      const el = $(id);
      const keep = K.saved(id);
      el.innerHTML = (id.endsWith("lo") ? `<option value="">${T("kr.none")}</option>` : "") + opts.join("");
      el.value = keep !== undefined ? keep : String(defaults[id]);
    });
    const render = () => {
      const myHi = +$("kr-my-hi").value, songHi = +$("kr-song-hi").value;
      const myLo = $("kr-my-lo").value === "" ? null : +$("kr-my-lo").value;
      const songLo = $("kr-song-lo").value === "" ? null : +$("kr-song-lo").value;
      let s = myHi - songHi;
      const label = (x) => x === 0 ? T("kr.same") : T(x > 0 ? "kr.up" : "kr.down", { n: Math.abs(x) });
      // 最低音も入っていれば、最高音と最低音の両方が入る位置を探す
      let note = "";
      if (myLo !== null && songLo !== null) {
        const myRange = myHi - myLo, songRange = songHi - songLo;
        if (songRange > myRange) {
          note = T("kr.tooWide", { song: songRange, my: myRange, d: songRange - myRange });
        } else if (songLo + s < myLo) {
          s = myLo - songLo; // 低い音に合わせる
          note = T("kr.fitLow");
        } else {
          note = T("kr.margin", { up: myHi - (songHi + s), down: (songLo + s) - myLo });
        }
      }
      $("kr-out").textContent = label(s);
      $("kr-after").textContent = T("kr.after", { note: noteLabel(songHi + s) });
      $("kr-note").textContent = note;
      // 1オクターブずらす案（男性が女性曲、女性が男性曲を歌うときなど）
      const alt = Math.abs(s) >= 6 ? (s < 0 ? s + 12 : s - 12) : null;
      $("kr-alt").textContent = alt === null ? "" : T(s < 0 ? "kr.altDown" : "kr.altUp", { label: label(alt) });
      $("kr-warn").textContent = Math.abs(s) > 7 ? T("kr.warn") : "";
    };
    ids.forEach((id) => $(id).addEventListener("change", render));
    render();
  }

  // ---------- ループ素材の長さからBPM ----------
  function loopBpm() {
    const sec = $("lp-sec");
    if (!sec) return;
    const bars = $("lp-bars"), beats = $("lp-beats");
    const render = () => {
      const s = num(sec), b = num(bars), p = num(beats);
      if (!(s > 0) || !(b > 0) || !(p > 0)) { $("lp-out").textContent = "—"; $("lp-alt").textContent = ""; return; }
      const bpm = b * p * 60 / s;
      $("lp-out").textContent = fmt(bpm, 2);
      $("lp-alt").textContent = T("lp.alt", { d: fmt(bpm * 2, 1), h: fmt(bpm / 2, 1) });
    };
    on([sec, bars, beats], "input", render);
    render();
  }

  // ---------- 結果のコピー ----------
  function copyButtons() {
    document.querySelectorAll(".readout").forEach((r) => {
      const big = r.querySelector(".big");
      if (!big || big.tagName === "INPUT" || r.querySelector(".copy")) return;
      const b = document.createElement("button");
      b.type = "button"; b.className = "copy"; b.textContent = T("copy");
      b.setAttribute("aria-label", T("copy.aria"));
      b.addEventListener("click", async () => {
        // 国によって「1.234,5」のように書くので、コピーするときは「1234.5」の形にそろえる
        const parts = new Intl.NumberFormat(LANG).formatToParts(1234.5);
        const group = (parts.find((p) => p.type === "group") || {}).value || ",";
        const dec = (parts.find((p) => p.type === "decimal") || {}).value || ".";
        const text = big.textContent.split(group).join("").replace(/\u00a0|\u202f/g, "").split(dec).join(".").trim();
        try {
          await navigator.clipboard.writeText(text);
          b.textContent = T("copy.done");
        } catch (e) {
          b.textContent = T("copy.fail");
        }
        setTimeout(() => { b.textContent = T("copy"); }, 1500);
      });
      r.appendChild(b);
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    comp(); eqq(); amp(); spl(); loud(); keyrange(); loopBpm(); copyButtons();
  });
})();
