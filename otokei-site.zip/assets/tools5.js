// おとけい 3周目（カポ計算・dBFS⇔dBu・位相の角度）と、iPhoneで音が出やすくする工夫
(function () {
  "use strict";
  const K = window.OTK;
  if (!K) return;
  const { $, num, fmt, ok, on, SHARP, FLAT, T } = K;

  const FLAT_KEYS = [5, 10, 3, 8, 1, 6];
  const nm = (pc, flat) => (flat ? FLAT : SHARP)[((pc % 12) + 12) % 12].replace("b", "♭").replace("#", "♯");
  const idx = (r) => {
    const map = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
    let n = map[r[0]];
    if (r[1] === "#" || r[1] === "♯") n += 1;
    if (r[1] === "b" || r[1] === "♭") n -= 1;
    return (n + 12) % 12;
  };

  // ---------- カポ計算 ----------
  const MAJOR_SHAPES = [["C", 0], ["G", 7], ["D", 2], ["A", 9], ["E", 4]];
  const MINOR_SHAPES = [["Am", 9], ["Em", 4], ["Dm", 2]];
  function capo() {
    const keySel = $("cp-key");
    if (!keySel) return;
    const modeSel = $("cp-mode"), prog = $("cp-prog");
    const labels = T("keys.labels").split(",");
    keySel.innerHTML = labels.map((l, i) => `<option value="${i}">${l}</option>`).join("");
    const sv = K.saved("cp-key"); keySel.value = sv !== undefined ? sv : "3";
    let chosen = null;
    const render = () => {
      const k = +keySel.value, minor = modeSel.value === "minor";
      const shapes = minor ? MINOR_SHAPES : MAJOR_SHAPES;
      const rows = shapes.map(([name, pc]) => ({ name, fret: (k - pc + 12) % 12 })).sort((a, b) => a.fret - b.fret);
      if (!chosen || !rows.some((r) => r.name === chosen)) chosen = rows.find((r) => r.fret <= 7) ? rows.find((r) => r.fret <= 7).name : rows[0].name;
      $("cp-rows").innerHTML = rows.map((r) => `<button type="button" class="capo-row${r.name === chosen ? " on" : ""}" data-shape="${r.name}" aria-pressed="${r.name === chosen}">
        <span class="capo-shape">${r.name}</span><span class="capo-fret">${r.fret === 0 ? T("capo.none") : T("capo.n", { n: r.fret })}</span>${r.fret > 7 ? `<span class="note">${T("capo.tooHigh")}</span>` : ""}</button>`).join("");
      $("cp-rows").querySelectorAll(".capo-row").forEach((b) => b.addEventListener("click", () => { chosen = b.dataset.shape; render(); }));
      const fret = rows.find((r) => r.name === chosen).fret;
      $("cp-title").textContent = T("capo.title", { key: `${nm(k, FLAT_KEYS.includes(k))}${minor ? "m" : ""}`, shape: chosen, capo: fret === 0 ? T("capo.none") : T("capo.nF", { n: fret }) });
      // コード進行を「押さえる形」に書きかえる
      const tokens = prog.value.trim().split(/\s+/).filter(Boolean);
      $("cp-out").innerHTML = tokens.map((t) => {
        const m = t.match(/^([A-G][#b♯♭]?)(.*?)(?:\/([A-G][#b♯♭]?))?$/);
        if (!m) return `<span class="chip muted">${t}</span>`;
        const useFlat = /[b♭]/.test(m[1]); // 入れた書き方（♭か♯か）に合わせる
        const shapeRoot = nm(idx(m[1]) - fret, useFlat), bass = m[3] ? "/" + nm(idx(m[3]) - fret, /[b♭]/.test(m[3])) : "";
        return `<span class="chip">${shapeRoot}${m[2]}${bass}<small>${t}</small></span>`;
      }).join("");
    };
    on([keySel, modeSel], "change", render); prog.addEventListener("input", render);
    render();
  }

  // ---------- dBFS ⇔ dBu ----------
  function dbfs() {
    const fs = $("fs-dbfs");
    if (!fs) return;
    const refFs = $("fs-ref-fs"), refU = $("fs-ref-u");
    const render = () => {
      const a = num(refFs), b = num(refU), x = num(fs);
      if (!isFinite(a) || !isFinite(b) || !isFinite(x)) { $("fs-dbu-out").textContent = "—"; return; }
      $("fs-dbu-out").textContent = fmt(x - a + b, 1);
      $("fs-max").textContent = fmt(0 - a + b, 1);
    };
    on([fs, refFs, refU], "input", render);
    document.querySelectorAll("[data-align]").forEach((btn) => btn.addEventListener("click", () => {
      const [f, u] = btn.dataset.align.split("|"); refFs.value = f; refU.value = u;
      [refFs, refU].forEach((e) => e.dispatchEvent(new Event("change"))); render();
    }));
    render();
  }

  // ---------- 遅れと位相の角度 ----------
  function phase() {
    const f = $("ph-freq");
    if (!f) return;
    const ms = $("ph-ms");
    const render = () => {
      const hz = num(f), t = num(ms);
      if (!(hz > 0) || !(t >= 0)) { $("ph-out").textContent = "—"; return; }
      const deg = (360 * hz * t / 1000) % 360;
      $("ph-out").textContent = fmt(deg, 0);
      $("ph-note").textContent = Math.abs(deg - 180) < 20 ? T("ph.opposite") : (deg < 20 || deg > 340) ? T("ph.same") : "";
    };
    on([f, ms], "input", render);
    render();
  }

  // ---------- iPhone で音が出やすくする ----------
  function unlock() {
    const needs = ["keyboard", "met-start", "tone-play", "ch-kb", "sc-kb", "hr-start", "st-buttons", "tu-start", "vr-start"].some((id) => $(id));
    if (!needs) return;
    try { if (navigator.audioSession) navigator.audioSession.type = "playback"; } catch (e) {} // マナーモードでも鳴らせるように（対応しているSafariのみ）
    const go = () => {
      const c = K.audio();
      if (c) { // 無音を一瞬鳴らして、音を出せる状態にしておく
        const b = c.createBuffer(1, 1, 22050), s = c.createBufferSource();
        s.buffer = b; s.connect(c.destination); s.start(0);
      }
      ["touchend", "click", "keydown"].forEach((ev) => document.removeEventListener(ev, go, true));
    };
    ["touchend", "click", "keydown"].forEach((ev) => document.addEventListener(ev, go, true));
  }

  document.addEventListener("DOMContentLoaded", () => { capo(); dbfs(); phase(); unlock(); });
})();
