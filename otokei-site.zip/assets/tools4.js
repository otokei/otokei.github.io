// おとけい 2周目のツール（音域チェック・タイムコード・残響時間・聞こえる高さ・左右と位相）と使いやすさ
(function () {
  "use strict";
  const K = window.OTK;
  if (!K) return;
  const { $, num, fmt, ok, on, audio, nameOf, T, LANG } = K;

  // ---------- マイクで音域チェック ----------
  function voiceRange() {
    const btn = $("vr-start");
    if (!btn) return;
    let stream = null, raf = 0, analyser = null, buf = null, recent = [], lo = null, hi = null;
    const show = () => {
      $("vr-hi").textContent = hi === null ? "—" : K.karaoke(hi);
      $("vr-hi-sub").textContent = hi === null ? "" : (LANG === "ja" ? T("vr.sub", { name: nameOf(hi), hz: fmt(K.freqOf(hi, 440), 1) }) : `${fmt(K.freqOf(hi, 440), 1)} Hz`);
      $("vr-lo").textContent = lo === null ? "—" : K.karaoke(lo);
      $("vr-lo-sub").textContent = lo === null ? "" : (LANG === "ja" ? T("vr.sub", { name: nameOf(lo), hz: fmt(K.freqOf(lo, 440), 1) }) : `${fmt(K.freqOf(lo, 440), 1)} Hz`);
      $("vr-span").textContent = lo === null ? "" : T("vr.span", { n: hi - lo, oct: fmt((hi - lo) / 12, 1) });
      $("vr-send").hidden = lo === null;
    };
    const stop = () => {
      cancelAnimationFrame(raf);
      if (stream) stream.getTracks().forEach((t) => t.stop());
      stream = null; btn.textContent = T("mic.on"); btn.setAttribute("aria-pressed", "false");
      $("vr-now").textContent = "—";
    };
    const loop = () => {
      analyser.getFloatTimeDomainData(buf);
      const f = K.detectPitch(buf, K.getCtx().sampleRate);
      if (f > 55 && f < 1400) {
        recent.push(69 + 12 * Math.log2(f / 440));
        if (recent.length > 14) recent.shift();
        // 0.2秒ほど同じ高さが続いたら「出せた音」として数える（雑音やしゃくりを数えない）
        if (recent.length >= 14) {
          const sorted = recent.slice().sort((a, b) => a - b), med = sorted[7];
          if (recent.every((x) => Math.abs(x - med) < 0.5)) {
            const m = Math.round(med);
            $("vr-now").textContent = K.noteLabel(m);
            if (hi === null || m > hi) hi = m;
            if (lo === null || m < lo) lo = m;
            show();
          }
        }
      } else {
        recent = [];
      }
      raf = requestAnimationFrame(loop);
    };
    btn.addEventListener("click", async () => {
      if (stream) { stop(); return; }
      const c = audio();
      if (!c || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { $("vr-error").textContent = T("mic.unsupported"); return; }
      try {
        stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false } });
      } catch (e) { $("vr-error").textContent = T("mic.denied"); return; }
      $("vr-error").textContent = "";
      const s = c.createMediaStreamSource(stream);
      analyser = c.createAnalyser(); analyser.fftSize = 4096; buf = new Float32Array(analyser.fftSize);
      s.connect(analyser); recent = [];
      btn.textContent = T("mic.off"); btn.setAttribute("aria-pressed", "true");
      loop();
    });
    $("vr-reset").addEventListener("click", () => { lo = hi = null; show(); $("vr-now").textContent = "—"; });
    // 「歌のキー合わせ」に自分の音域を渡す
    $("vr-send").addEventListener("click", () => {
      try {
        const key = "otokei:keyrange.html";
        const d = JSON.parse(localStorage.getItem(key) || "{}");
        d["kr-my-hi"] = String(hi); d["kr-my-lo"] = String(lo);
        localStorage.setItem(key, JSON.stringify(d));
      } catch (e) {}
      location.href = "keyrange.html";
    });
    K.voiceRangeTest = (m) => { if (hi === null || m > hi) hi = m; if (lo === null || m < lo) lo = m; show(); };
    show();
  }

  // ---------- タイムコード・フレーム ----------
  const FPS = {
    "23.976": { real: 24000 / 1001, base: 24, drop: 0 }, "24": { real: 24, base: 24, drop: 0 }, "25": { real: 25, base: 25, drop: 0 },
    "29.97df": { real: 30000 / 1001, base: 30, drop: 2 }, "29.97": { real: 30000 / 1001, base: 30, drop: 0 }, "30": { real: 30, base: 30, drop: 0 },
    "50": { real: 50, base: 50, drop: 0 }, "59.94df": { real: 60000 / 1001, base: 60, drop: 4 }, "59.94": { real: 60000 / 1001, base: 60, drop: 0 }, "60": { real: 60, base: 60, drop: 0 }
  };
  const pad = (n) => String(n).padStart(2, "0");
  // フレーム番号 → タイムコード（ドロップフレームは毎分のはじめに番号を飛ばす。10分ごとは飛ばさない）
  function framesToTC(frames, r) {
    let f = frames;
    if (r.drop) {
      const per10 = r.base * 600 - r.drop * 9, perMin = r.base * 60 - r.drop;
      const d = Math.floor(f / per10), m = f % per10;
      f += r.drop * 9 * d + (m > r.drop ? r.drop * Math.floor((m - r.drop) / perMin) : 0);
    }
    const ff = f % r.base, ss = Math.floor(f / r.base) % 60, mm = Math.floor(f / (r.base * 60)) % 60, hh = Math.floor(f / (r.base * 3600));
    return `${pad(hh)}:${pad(mm)}:${pad(ss)}${r.drop ? ";" : ":"}${pad(ff)}`;
  }
  function tcToFrames(tc, r) {
    const p = tc.trim().split(/[:;.,]/).map((x) => parseInt(x, 10));
    if (p.length !== 4 || p.some((x) => !isFinite(x) || x < 0)) return null;
    const [hh, mm, ss, ff] = p;
    if (mm > 59 || ss > 59 || ff >= r.base) return null;
    if (r.drop && ss === 0 && mm % 10 !== 0 && ff < r.drop) return null; // 存在しない番号
    const total = hh * 60 + mm;
    return (hh * 3600 + mm * 60 + ss) * r.base + ff - (r.drop ? r.drop * (total - Math.floor(total / 10)) : 0);
  }
  K.tc = { framesToTC, tcToFrames, FPS };
  function timecode() {
    const sel = $("tc-fps");
    if (!sel) return;
    const sec = $("tc-sec"), tcIn = $("tc-in");
    const r1 = () => {
      const r = FPS[sel.value], s = num(sec);
      $("tc-per").textContent = T("tc.per", { ms: fmt(1000 / r.real, 3), smp: fmt(48000 / r.real, 1) });
      if (!(s >= 0)) { $("tc-out").textContent = "—"; $("tc-frames").textContent = "—"; return; }
      const fr = Math.round(s * r.real);
      $("tc-out").textContent = framesToTC(fr, r);
      $("tc-frames").textContent = fmt(fr, 0);
    };
    const r2 = () => {
      const r = FPS[sel.value], fr = tcToFrames(tcIn.value, r);
      if (fr === null) { $("tc-back").textContent = "—"; $("tc-back-err").textContent = tcIn.value.trim() ? T("tc.err") : ""; return; }
      $("tc-back-err").textContent = "";
      const s = fr / r.real, h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = s - h * 3600 - m * 60;
      $("tc-back").textContent = T("time.hms", { h, m, s: fmt(ss, 3) });
      $("tc-back-fr").textContent = T("tc.frames", { n: fmt(fr, 0) });
    };
    sel.addEventListener("change", () => { r1(); r2(); });
    sec.addEventListener("input", r1); tcIn.addEventListener("input", r2);
    r1(); r2();
  }

  // ---------- 残響時間 ----------
  function reverb() {
    const L = $("rv-l");
    if (!L) return;
    const W = $("rv-w"), H = $("rv-h"), a = $("rv-a");
    const render = () => {
      const l = num(L), w = num(W), h = num(H), al = num(a);
      if (!(l > 0 && w > 0 && h > 0) || !ok(al, 0.01, 0.99)) { $("rv-out").textContent = "—"; return; }
      const V = l * w * h, S = 2 * (l * w + l * h + w * h);
      const sabine = 0.161 * V / (S * al), eyring = 0.161 * V / (-S * Math.log(1 - al));
      $("rv-out").textContent = fmt(sabine, 2);
      $("rv-ey").textContent = fmt(eyring, 2);
      $("rv-vs").textContent = T("rv.vs", { v: fmt(V, 1), s: fmt(S, 1) });
    };
    on([L, W, H, a], "input", render);
    document.querySelectorAll("[data-alpha]").forEach((b) => b.addEventListener("click", () => { a.value = b.dataset.alpha; a.dispatchEvent(new Event("change")); render(); }));
    render();
  }

  // ---------- 聞こえる高さテスト ----------
  function hearing() {
    const start = $("hr-start");
    if (!start) return;
    const STEPS = [8000, 10000, 12000, 13000, 14000, 15000, 16000, 17000, 18000, 19000, 20000];
    let osc = null, gain = null, timer = 0, idx = -1;
    const vol = $("hr-vol");
    const stopTone = () => {
      clearInterval(timer); timer = 0;
      if (osc) { const c = K.getCtx(); gain.gain.setTargetAtTime(0, c.currentTime, 0.02); const o = osc; setTimeout(() => { try { o.stop(); } catch (e) {} }, 100); osc = null; }
      start.textContent = T("hr.start"); start.setAttribute("aria-pressed", "false");
      $("hr-stop").disabled = true;
    };
    const setStep = (i) => {
      idx = i;
      const f = STEPS[i];
      $("hr-now").textContent = fmt(f / 1000, 0);
      osc.frequency.setValueAtTime(f, K.getCtx().currentTime);
      document.querySelectorAll("#hr-steps span").forEach((s, j) => s.classList.toggle("lit", j <= i));
    };
    start.addEventListener("click", () => {
      if (timer || osc) { stopTone(); return; }
      const c = audio(); if (!c) return;
      osc = c.createOscillator(); gain = c.createGain(); gain.gain.value = 0;
      osc.type = "sine"; osc.connect(gain).connect(c.destination); osc.start();
      gain.gain.setTargetAtTime(Math.pow(num(vol) / 100, 2) * 0.4, c.currentTime, 0.05);
      setStep(0);
      $("hr-result").textContent = "";
      timer = setInterval(() => {
        if (idx + 1 >= STEPS.length) { $("hr-result").textContent = T("hr.all"); stopTone(); return; }
        setStep(idx + 1);
      }, 2500);
      start.textContent = T("btn.stopSound"); start.setAttribute("aria-pressed", "true");
      $("hr-stop").disabled = false;
    });
    $("hr-stop").addEventListener("click", () => {
      if (idx < 0) return;
      const heard = idx > 0 ? STEPS[idx - 1] : null;
      $("hr-result").textContent = heard ? T("hr.result", { a: fmt(heard / 1000, 0), b: fmt(STEPS[idx] / 1000, 0) }) : T("hr.none");
      stopTone();
    });
    vol.addEventListener("input", () => { if (gain) gain.gain.setTargetAtTime(Math.pow(num(vol) / 100, 2) * 0.4, K.getCtx().currentTime, 0.02); });
    $("hr-steps").innerHTML = STEPS.map((f) => `<span>${f / 1000}k</span>`).join("");
  }

  // ---------- 左右・位相チェック ----------
  function stereo() {
    const box = $("st-buttons");
    if (!box) return;
    let src = null, gl = null, gr = null, current = null, noise = null;
    const makeNoise = (c) => {
      const len = c.sampleRate * 2, b = c.createBuffer(1, len, c.sampleRate), d = b.getChannelData(0);
      let b0 = 0, b1 = 0, b2 = 0;
      for (let i = 0; i < len; i++) {
        const w = Math.random() * 2 - 1;
        b0 = 0.99765 * b0 + w * 0.0990460; b1 = 0.96300 * b1 + w * 0.2965164; b2 = 0.57000 * b2 + w * 1.0526913;
        d[i] = (b0 + b1 + b2 + w * 0.1848) * 0.12; // ピンクノイズに近い音（低い音まで入るので位相の違いが分かりやすい）
      }
      return b;
    };
    const stop = () => {
      if (src) { const c = K.getCtx(); gl.gain.setTargetAtTime(0, c.currentTime, 0.03); gr.gain.setTargetAtTime(0, c.currentTime, 0.03); const s = src; setTimeout(() => { try { s.stop(); } catch (e) {} }, 150); src = null; }
      current = null;
      box.querySelectorAll("button").forEach((b) => b.setAttribute("aria-pressed", "false"));
      $("st-L").classList.remove("on"); $("st-R").classList.remove("on");
      $("st-msg").textContent = "";
    };
    const MODES = {
      left: [1, 0, T("st.left")],
      right: [0, 1, T("st.right")],
      center: [1, 1, T("st.center")],
      invert: [1, -1, T("st.invert")]
    };
    box.querySelectorAll("button").forEach((b) => b.addEventListener("click", () => {
      const mode = b.dataset.mode;
      if (current === mode) { stop(); return; }
      const c = audio(); if (!c) return;
      if (!src) {
        noise = noise || makeNoise(c);
        src = c.createBufferSource(); src.buffer = noise; src.loop = true;
        gl = c.createGain(); gr = c.createGain(); gl.gain.value = 0; gr.gain.value = 0;
        const merger = c.createChannelMerger(2);
        src.connect(gl).connect(merger, 0, 0); src.connect(gr).connect(merger, 0, 1);
        merger.connect(c.destination); src.start();
      }
      const [l, r, msg] = MODES[mode], v = Math.pow(num($("st-vol")) / 100, 2) * 0.8;
      gl.gain.setTargetAtTime(l * v, c.currentTime, 0.03); gr.gain.setTargetAtTime(r * v, c.currentTime, 0.03);
      current = mode;
      box.querySelectorAll("button").forEach((x) => x.setAttribute("aria-pressed", String(x === b)));
      $("st-L").classList.toggle("on", l !== 0); $("st-R").classList.toggle("on", r !== 0);
      $("st-msg").textContent = msg;
    }));
    $("st-stop").addEventListener("click", stop);
  }

  // ---------- 最近使ったツール ----------
  function recent() {
    const page = location.pathname.split("/").pop() || "index.html";
    let list = [];
    try { list = JSON.parse(localStorage.getItem("otokei:recent") || "[]"); } catch (e) {}
    if (document.body.dataset.kind === "tool") {
      list = [page].concat(list.filter((p) => p !== page)).slice(0, 8);
      try { localStorage.setItem("otokei:recent", JSON.stringify(list)); } catch (e) {}
      return;
    }
    const box = $("recent");
    if (!box || !list.length) return;
    const apps = list.map((p) => document.querySelector(`#tools .app[href="${p}"]`)).filter(Boolean);
    if (!apps.length) return;
    $("recent-apps").innerHTML = apps.map((a) => a.outerHTML).join("");
    box.hidden = false;
  }

  // ---------- 波長ページの周期 ----------
  function period() {
    const f = $("wl-freq");
    if (!f || !$("wl-period")) return;
    const r = () => { const v = num(f); $("wl-period").textContent = v > 0 ? fmt(1000 / v, v > 1000 ? 4 : 2) : "—"; };
    f.addEventListener("input", r); r();
  }

  // ---------- 画面の明るさ（ダークモード） ----------
  function theme() {
    const btn = $("theme-btn");
    if (!btn) return;
    const label = () => {
      const dark = document.documentElement.dataset.theme === "dark" ||
        (!document.documentElement.dataset.theme && window.matchMedia && matchMedia("(prefers-color-scheme: dark)").matches);
      btn.textContent = dark ? T("theme.light") : T("theme.dark");
      return dark;
    };
    // 保存できない環境（試し見のページなど）でも、次のページへ「?t=dark」を付けて選んだ明るさを引きつぐ
    const carry = (v) => {
      document.querySelectorAll("a[href]").forEach((a) => {
        const h = a.getAttribute("href");
        if (/^(https?:|#|mailto:)/.test(h) || !/\.html/.test(h)) return;
        const [path, hash] = h.split("#");
        const clean = path.replace(/([?&])t=(dark|light)&?/, "$1").replace(/[?&]$/, "");
        a.setAttribute("href", clean + (clean.includes("?") ? "&" : "?") + "t=" + v + (hash !== undefined ? "#" + hash : ""));
      });
    };
    btn.addEventListener("click", () => {
      const next = label() ? "light" : "dark";
      document.documentElement.dataset.theme = next;
      try { localStorage.setItem("otokei:theme", next); } catch (e) {}
      try { document.cookie = "otokei_theme=" + next + "; path=/; max-age=31536000; SameSite=Lax"; } catch (e) {}
      // 保存できない環境でも、同じタブの中ではページを移っても覚えておく
      try { window.name = (window.name || "").replace(/otokei-theme=\w+;?/, "") + "otokei-theme=" + next + ";"; } catch (e) {}
      carry(next);
      label();
    });
    if (window.OTK_THEME_CARRY) carry(document.documentElement.dataset.theme);
    // 戻るボタンで前のページに戻ったときや、ほかのアプリから戻ってきたときも、最後に選んだ明るさに合わせる
    const saved = () => {
      let t = null;
      try { t = localStorage.getItem("otokei:theme"); } catch (e) {}
      if (!t) { const c = document.cookie.match(/(?:^|; )otokei_theme=(dark|light)/); if (c) t = c[1]; }
      if (!t) { const w = (window.name || "").match(/otokei-theme=(dark|light)/); if (w) t = w[1]; }
      return t;
    };
    const sync = () => {
      const t = saved();
      if (t && document.documentElement.dataset.theme !== t) {
        document.documentElement.dataset.theme = t;
        carry(t);
      }
      label();
    };
    window.addEventListener("pageshow", sync);
    window.addEventListener("focus", sync);
    window.addEventListener("storage", (e) => { if (!e.key || e.key === "otokei:theme") sync(); });
    document.addEventListener("visibilitychange", () => { if (!document.hidden) sync(); });
    label();
  }

  // ---------- オフラインで使えるようにする（本番のサイトでだけ動く） ----------
  function offline() {
    try {
      if ("serviceWorker" in navigator && /^https?:$/.test(location.protocol) && location.hostname !== "localhost") {
        navigator.serviceWorker.register("sw.js").catch(() => {});
      }
    } catch (e) {}
  }

  document.addEventListener("DOMContentLoaded", () => {
    voiceRange(); timecode(); reverb(); hearing(); stereo(); recent(); period(); theme(); offline();
  });
})();
