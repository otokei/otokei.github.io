// おとけい：コード解析の計算部分（音 → CQT → AIの出力 → コード区間）
// ブラウザ（Worker）でも Node でも動くように、外のものに頼らない書き方にしている
(function (root) {
  "use strict";
  var SR = 22050, HOP = 2048, NB = 144, BPO = 24, SEQ = 108;
  var FMIN = 440 * Math.pow(2, (24 - 69) / 12); // C1
  // 自作CQTを、AIが学習したときの計算（librosa）にそろえるための補正（1本ずつ）
  var OFF = [9.962, 9.9882, 9.9682, 9.9532, 9.9289, 9.9008, 9.8754, 9.8462, 9.775, 9.7357, 9.6944, 9.6615, 9.6401, 9.6132, 9.5795, 9.5579, 9.5362, 9.5126, 9.4879, 9.4913, 9.4714, 9.4426, 9.4166, 9.3806, 9.359, 9.3072, 9.2858, 9.2417, 9.2243, 9.2124, 9.1634, 9.1459, 9.1169, 9.0953, 9.056, 9.0422, 9.0128, 8.9823, 8.9278, 8.9156, 8.8919, 8.8601, 8.8202, 8.8012, 8.7719, 8.7471, 8.7184, 8.6932, 8.6542, 8.6327, 8.6053, 8.5747, 8.5439, 8.5213, 8.489, 8.4557, 8.4328, 8.4014, 8.3609, 8.345, 8.3175, 8.2846, 8.2563, 8.2299, 8.2048, 8.1759, 8.1439, 8.1143, 8.0885, 8.0602, 8.0338, 8.0092, 7.968, 7.9408, 7.9174, 7.8843, 7.8561, 7.8332, 7.8023, 7.7676, 7.745, 7.7158, 7.6866, 7.6609, 7.63, 7.5983, 7.5706, 7.5374, 7.5139, 7.4855, 7.4559, 7.4249, 7.3979, 7.3669, 7.341, 7.3167, 7.2809, 7.2484, 7.225, 7.1936, 7.1666, 7.1412, 7.1098, 7.0754, 7.0523, 7.0232, 6.9927, 6.9681, 6.9364, 6.9058, 6.8787, 6.847, 6.8206, 6.7913, 6.7606, 6.7312, 6.7044, 6.6737, 6.6464, 6.6195, 6.5884, 6.5584, 6.5312, 6.4995, 6.4729, 6.4447, 6.4148, 6.3845, 6.3582, 6.3312, 6.301, 6.2733, 6.2428, 6.2106, 6.1851, 6.1521, 6.1278, 6.1011, 6.0702, 6.037, 6.0131, 5.9808, 5.9538, 5.9294];

  // ---- FFT（2のべき乗、その場で計算）----
  function makeFFT(n) {
    var lev = Math.log2(n) | 0, rev = new Uint32Array(n), cos = new Float64Array(n / 2), sin = new Float64Array(n / 2);
    for (var i = 0; i < n; i++) { var r = 0, x = i; for (var b = 0; b < lev; b++) { r = (r << 1) | (x & 1); x >>= 1; } rev[i] = r; }
    for (i = 0; i < n / 2; i++) { cos[i] = Math.cos(2 * Math.PI * i / n); sin[i] = Math.sin(2 * Math.PI * i / n); }
    return function (re, im) { // 前向き（e^{-i...}）
      for (var i = 0; i < n; i++) { var j = rev[i]; if (j > i) { var t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t; } }
      for (var size = 2; size <= n; size <<= 1) {
        var half = size >> 1, step = n / size;
        for (var s = 0; s < n; s += size) {
          for (var k = 0, w = 0; k < half; k++, w += step) {
            var a = s + k, b2 = a + half;
            var tr = re[b2] * cos[w] + im[b2] * sin[w], ti = im[b2] * cos[w] - re[b2] * sin[w];
            re[b2] = re[a] - tr; im[b2] = im[a] - ti; re[a] += tr; im[a] += ti;
          }
        }
      }
    };
  }

  var KER = null; // 144本の、まばらにしたCQTフィルタ
  function kernels() {
    if (KER) return KER;
    var r = Math.pow(2, 1 / BPO), alpha = (r * r - 1) / (r * r + 1), Q = 1 / alpha;
    var lens = [], maxL = 0;
    for (var k = 0; k < NB; k++) { var f = FMIN * Math.pow(2, k / BPO), L = Q * SR / f; lens.push([f, L]); if (L > maxL) maxL = L; }
    var N = 1 << Math.ceil(Math.log2(maxL)), H = N / 2 + 1, fft = makeFFT(N);
    var re = new Float64Array(N), im = new Float64Array(N), rows = [];
    for (k = 0; k < NB; k++) {
      f = lens[k][0]; L = lens[k][1];
      re.fill(0); im.fill(0);
      var n0 = Math.floor(-L / 2), cnt = Math.floor(L / 2) - n0, start = (N - cnt) >> 1, sum = 0, i;
      for (i = 0; i < cnt; i++) {
        var n = n0 + i, w = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / cnt), ph = 2 * Math.PI * f / SR * n;
        re[start + i] = Math.cos(ph) * w; im[start + i] = Math.sin(ph) * w; sum += w;
      }
      for (i = 0; i < cnt; i++) { re[start + i] /= sum; im[start + i] /= sum; }
      fft(re, im);
      var sc = 1 / (N * Math.sqrt(L)), mags = new Float64Array(H), tot = 0;
      for (i = 0; i < H; i++) { mags[i] = Math.hypot(re[i], im[i]); tot += mags[i]; }
      // 小さい成分を合計1%ぶん捨てる（librosa と同じ考え方）
      var order = Array.from(mags.keys()).sort(function (a, b) { return mags[a] - mags[b]; }), cut = 0, acc = 0;
      while (cut < H && acc + mags[order[cut]] < 0.01 * tot) { acc += mags[order[cut]]; cut++; }
      var keep = order.slice(cut).sort(function (a, b) { return a - b; });
      var idx = new Int32Array(keep.length), kr = new Float64Array(keep.length), ki = new Float64Array(keep.length);
      for (i = 0; i < keep.length; i++) { var j = keep[i]; idx[i] = j; kr[i] = re[j] * sc; ki[i] = -im[j] * sc; } // 複素共役
      rows.push({ idx: idx, kr: kr, ki: ki });
    }
    KER = { N: N, rows: rows, fft: makeFFT(N / 2), H: H };
    return KER;
  }

  // 実数の信号のFFT（半分の長さの複素FFTで計算）
  function rfft(K, frame, outRe, outIm, bufRe, bufIm) {
    var M = K.N / 2;
    for (var i = 0; i < M; i++) { bufRe[i] = frame[2 * i]; bufIm[i] = frame[2 * i + 1]; }
    K.fft(bufRe, bufIm);
    for (var k = 0; k <= M; k++) {
      var a = k % M, b = (M - k) % M;
      var er = (bufRe[a] + bufRe[b]) / 2, ei = (bufIm[a] - bufIm[b]) / 2;
      var or = (bufIm[a] + bufIm[b]) / 2, oi = -(bufRe[a] - bufRe[b]) / 2;
      var ang = -2 * Math.PI * k / K.N, c = Math.cos(ang), s = Math.sin(ang);
      outRe[k] = er + (or * c - oi * s); outIm[k] = ei + (or * s + oi * c);
    }
  }

  // 22050Hz・モノラルの音 → [フレーム数][144] の対数CQT（AIの入力）
  function features(y, onProgress) {
    var K = kernels(), N = K.N, T = 1 + Math.floor(y.length / HOP);
    var frame = new Float32Array(N), xr = new Float64Array(K.H), xi = new Float64Array(K.H), br = new Float64Array(N / 2), bi = new Float64Array(N / 2);
    var out = new Float32Array(T * NB);
    for (var t = 0; t < T; t++) {
      var c = t * HOP, s = c - N / 2;
      for (var i = 0; i < N; i++) { var p = s + i; frame[i] = (p >= 0 && p < y.length) ? y[p] : 0; }
      rfft(K, frame, xr, xi, br, bi);
      for (var k = 0; k < NB; k++) {
        var R = K.rows[k], ar = 0, ai = 0;
        for (var j = 0; j < R.idx.length; j++) { var q = R.idx[j]; ar += R.kr[j] * xr[q] - R.ki[j] * xi[q]; ai += R.kr[j] * xi[q] + R.ki[j] * xr[q]; }
        out[t * NB + k] = Math.log(Math.hypot(ar, ai) + 1e-6) + OFF[k];
      }
      if (onProgress && t % 64 === 0) onProgress(t / T);
    }
    return { data: out, T: T };
  }

  // AIを区切りごとに動かして、結果を平均する。run(batchFloat32, n) → Promise<Float32Array(n*108*170)>
  async function logits(F, mean, std, run, onProgress) {
    var T = F.T, C = 170, pad = (SEQ - T % SEQ) % SEQ, TP = T + pad + SEQ;
    var X = new Float32Array(TP * NB);
    for (var i = 0; i < T * NB; i++) X[i] = (F.data[i] - mean) / std;
    for (i = T * NB; i < TP * NB; i++) X[i] = (0 - mean) / std;
    var acc = new Float32Array(TP * C), cnt = new Float32Array(TP), starts = [];
    for (var s = 0; s < T + pad; s += SEQ / 2) starts.push(s);
    for (var b = 0; b < starts.length; b += 16) {
      var ss = starts.slice(b, b + 16), batch = new Float32Array(ss.length * SEQ * NB);
      ss.forEach(function (st, n) { batch.set(X.subarray(st * NB, (st + SEQ) * NB), n * SEQ * NB); });
      var o = await run(batch, ss.length);
      ss.forEach(function (st, n) {
        for (var t = 0; t < SEQ; t++) { cnt[st + t]++; for (var c = 0; c < C; c++) acc[(st + t) * C + c] += o[(n * SEQ + t) * C + c]; }
      });
      if (onProgress) onProgress(Math.min(1, (b + 16) / starts.length));
    }
    var L = new Float32Array(T * C);
    for (var t = 0; t < T; t++) for (var c = 0; c < C; c++) L[t * C + c] = acc[t * C + c] / cnt[t];
    // ガウスでなめらかに（9フレーム）
    var k = 9, sig = k / 6, w = [], ws = 0;
    for (i = 0; i < k; i++) { var v = Math.exp(-0.5 * Math.pow((i - 4) / sig, 2)); w.push(v); ws += v; }
    var S = new Float32Array(T * C);
    for (t = 0; t < T; t++) for (i = 0; i < k; i++) {
      var tt = Math.min(T - 1, Math.max(0, t + i - 4)), wi = w[i] / ws;
      for (c = 0; c < C; c++) S[t * C + c] += wi * L[tt * C + c];
    }
    return { L: S, T: T, C: C };
  }

  // 一番点数の高いコード → 多数決でならす → 区間にまとめる
  function segments(R, idx2chord, minDur) {
    var T = R.T, C = R.C, p = new Int32Array(T);
    for (var t = 0; t < T; t++) { var best = 0; for (var c = 1; c < C; c++) if (R.L[t * C + c] > R.L[t * C + best]) best = c; p[t] = best; }
    var q = new Int32Array(T), k = 9;
    for (t = 0; t < T; t++) {
      var cnts = {}, mx = 0;
      for (var i = -4; i <= 4; i++) { var v = p[Math.min(T - 1, Math.max(0, t + i))]; cnts[v] = (cnts[v] || 0) + 1; if (cnts[v] > mx) mx = cnts[v]; }
      if (cnts[p[t]] === mx) q[t] = p[t];
      else { var cand = Object.keys(cnts).filter(function (x) { return cnts[x] === mx; }).map(Number).sort(function (a, b) { return a - b; }); q[t] = cand[0]; }
    }
    var fd = HOP / SR, seg = [], s = 0;
    for (t = 1; t <= T; t++) if (t === T || q[t] !== q[s]) { seg.push([s * fd, t * fd, q[s]]); s = t; }
    var out = [];
    seg.forEach(function (a) {
      if (out.length && a[1] - a[0] < (minDur || 0.5)) out[out.length - 1][1] = a[1];
      else if (out.length && out[out.length - 1][2] === a[2]) out[out.length - 1][1] = a[1];
      else out.push(a.slice());
    });
    // 曲の頭の短い区間は、次のコードにふくめる
    while (out.length > 1 && out[0][1] - out[0][0] < (minDur || 0.5)) { out[1][0] = out[0][0]; out.shift(); }
    return out.map(function (a) { return { start: a[0], end: a[1], idx: a[2], label: idx2chord[a[2]] }; });
  }

  // 音の成分（12音ごとの強さ）から調を当てる（Krumhansl のキープロファイル）
  function chroma(F) {
    var ch = new Float64Array(12);
    for (var t = 0; t < F.T; t++) for (var k = 0; k < NB; k++) {
      var e = Math.exp(F.data[t * NB + k] - OFF[k]); ch[Math.round(k / 2) % 12] += e;
    }
    return ch;
  }
  var MAJ = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88];
  var MIN = [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17];
  function corr(a, b) {
    var ma = 0, mb = 0, n = a.length, i; for (i = 0; i < n; i++) { ma += a[i]; mb += b[i]; } ma /= n; mb /= n;
    var s = 0, sa = 0, sb = 0; for (i = 0; i < n; i++) { s += (a[i] - ma) * (b[i] - mb); sa += Math.pow(a[i] - ma, 2); sb += Math.pow(b[i] - mb, 2); }
    return s / Math.sqrt(sa * sb + 1e-12);
  }
  // コード区間の長さも使って調を決める（音の成分＋コードの合わせ技）
  function key(F, segs) {
    var ch = chroma(F), cc = new Float64Array(12);
    var Q = { "maj": [0, 4, 7], "min": [0, 3, 7], "7": [0, 4, 7, 10], "maj7": [0, 4, 7, 11], "min7": [0, 3, 7, 10] };
    segs.forEach(function (s) {
      var m = /^([A-G][#b]?)(?::(\w+))?/.exec(s.label || ""); if (!m) return;
      var r = pc(m[1]), iv = Q[m[2] || "maj"] || [0, 7];
      iv.forEach(function (x) { cc[(r + x) % 12] += s.end - s.start; });
    });
    var tot = ch.reduce(function (a, b) { return a + b; }, 0) || 1, tc = cc.reduce(function (a, b) { return a + b; }, 0) || 1;
    var mix = []; for (var i = 0; i < 12; i++) mix.push(ch[i] / tot + cc[i] / tc);
    var best = null;
    for (var r = 0; r < 12; r++) [["maj", MAJ], ["min", MIN]].forEach(function (m) {
      var rot = []; for (var i = 0; i < 12; i++) rot.push(m[1][(i - r + 12) % 12]);
      var v = corr(mix, rot); if (!best || v > best.score) best = { tonic: r, mode: m[0], score: v };
    });
    return best;
  }
  function pc(n) {
    var b = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 }[n[0]];
    if (n[1] === "#") b++; if (n[1] === "b") b--; return (b + 12) % 12;
  }

  root.ChordCore = { SR: SR, features: features, logits: logits, segments: segments, key: key, pc: pc };
})(typeof self !== "undefined" ? self : globalThis);
