// おとけい：コード解析を裏で動かす係（画面が固まらないように）
var ORT = "https://cdn.jsdelivr.net/npm/onnxruntime-web@1.31.1/dist/";
importScripts(ORT + "ort.wasm.min.js", "chordcore.js");
ort.env.wasm.wasmPaths = ORT;
ort.env.wasm.numThreads = 1;

var sess = null, meta = null;
function say(stage, p) { postMessage({ type: "progress", stage: stage, p: p }); }

async function load() {
  if (sess) return;
  say("model", 0);
  var res = await fetch("chordnet.onnx");
  if (!res.ok) throw new Error("model " + res.status);
  var total = +res.headers.get("content-length") || 9558423, got = 0, parts = [];
  var rd = res.body.getReader();
  for (;;) {
    var r = await rd.read(); if (r.done) break;
    parts.push(r.value); got += r.value.length; say("model", Math.min(1, got / total));
  }
  var buf = new Uint8Array(got), o = 0;
  parts.forEach(function (p) { buf.set(p, o); o += p.length; });
  sess = await ort.InferenceSession.create(buf, { executionProviders: ["wasm"] });
  meta = await (await fetch("chordmeta.json")).json();
}

onmessage = async function (e) {
  try {
    await load();
    var y = e.data.y;
    var F = ChordCore.features(y, function (p) { say("cqt", p); });
    say("cqt", 1);
    var R = await ChordCore.logits(F, meta.mean, meta.std, async function (b, n) {
      var out = await sess.run({ x: new ort.Tensor("float32", b, [n, 108, 144]) });
      return out.logits.data;
    }, function (p) { say("ai", p); });
    var segs = ChordCore.segments(R, meta.idx2chord, 0.5);
    var key = ChordCore.key(F, segs);
    say("beat", 0.5);
    var B = ChordCore.beats(y), A = ChordCore.align(segs, B);
    postMessage({ type: "done", segs: A.segs, key: key, beats: B.times, bpm: B.bpm, down: A.down });
  } catch (err) {
    postMessage({ type: "error", message: String(err && err.message || err) });
  }
};
