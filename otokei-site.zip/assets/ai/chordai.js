// おとけい：コード解析（耳コピAI）の画面
(function () {
  "use strict";
  var K = window.OTK;
  var drop = document.getElementById("ca-drop");
  if (!K || !drop) return;
  var T = K.T, $ = K.$;
  var BASE = (document.currentScript && document.currentScript.src || location.href).replace(/[^/]*$/, "");
  var SHARP = ["C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B"];
  var FLAT = ["C", "D♭", "D", "E♭", "E", "F", "G♭", "G", "A♭", "A", "B♭", "B"];
  var ASCII = function (s) { return s.replace(/♯/g, "#").replace(/♭/g, "b"); };
  var QUAL = ["maj", "min", "7", "maj7", "min7", "sus4", "sus2", "dim", "aug", "maj6", "min6", "dim7", "hdim7", "minmaj7"];
  var SFX = { maj: "", min: "m", "7": "7", maj7: T("ca.sfxMaj7"), min7: "m7", sus4: "sus4", sus2: "sus2", dim: "dim", aug: "aug", maj6: "6", min6: "m6", dim7: "dim7", hdim7: "m7(♭5)", minmaj7: "mM7" };
  var SIMPLE = { maj: "maj", "7": "maj", maj7: "maj", maj6: "maj", sus4: "maj", sus2: "maj", aug: "maj", min: "min", min7: "min", min6: "min", minmaj7: "min", dim: "dim", dim7: "dim", hdim7: "dim" };
  var DEG = ["Ⅰ", "♭Ⅱ", "Ⅱ", "♭Ⅲ", "Ⅲ", "Ⅳ", "♯Ⅳ", "Ⅴ", "♭Ⅵ", "Ⅵ", "♭Ⅶ", "Ⅶ"];
  var FLAT_MAJ = [5, 10, 3, 8, 1, 6];

  var file = $("ca-file"), status = $("ca-status"), prog = $("ca-prog"), result = $("ca-result");
  var audio = $("ca-audio"), grid = $("ca-grid"), cur = $("ca-cur"), next = $("ca-next");
  var shiftEl = $("ca-shift"), flatEl = $("ca-flat"), simpleEl = $("ca-simple"), degEl = $("ca-degree"), loopEl = $("ca-loop");
  var editRow = $("ca-edit"), rootSel = $("ca-root"), qualSel = $("ca-qual");
  var segs = [], key = null, sel = -1, worker = null, url = null, playing = -1, t0 = 0;

  function setStatus(msg, p) {
    status.textContent = msg || "";
    if (p == null) prog.hidden = true; else { prog.hidden = false; prog.value = p; }
  }
  function mmss(s) { s = Math.max(0, s); var m = Math.floor(s / 60), r = Math.floor(s % 60); return m + ":" + (r < 10 ? "0" : "") + r; }
  function shift() { return parseInt(shiftEl.value, 10) || 0; }
  function majTonic() { return key ? (key.mode === "min" ? (key.tonic + 3) % 12 : key.tonic) : 0; }
  function useFlat() { return flatEl.checked; }
  function nameRoot(pc) { return (useFlat() ? FLAT : SHARP)[((pc % 12) + 12) % 12]; }
  function label(s) {
    if (s.root < 0) return "N.C.";
    var q = simpleEl.checked ? SIMPLE[s.q] || s.q : s.q;
    if (degEl.checked) {
      var d = DEG[((s.root - majTonic()) % 12 + 12) % 12];
      return d + SFX[q];
    }
    return nameRoot(s.root + shift()) + SFX[q];
  }
  function keyName() {
    if (!key) return "";
    var n = nameRoot(key.tonic + shift());
    return T(key.mode === "min" ? "ca.keyMin" : "ca.keyMaj", { k: n });
  }
  // 表示上同じになるとなりのコードはまとめる
  function view() {
    var v = [];
    segs.forEach(function (s, i) {
      var l = label(s), last = v[v.length - 1];
      if (last && last.label === l) { last.end = s.end; last.ids.push(i); }
      else v.push({ start: s.start, end: s.end, label: l, ids: [i] });
    });
    return v;
  }
  function render() {
    var v = view();
    $("ca-key").textContent = T("ca.key", { key: keyName() });
    var sh = shift();
    $("ca-shift-label").textContent = sh === 0 ? T("tr.same") : T(sh > 0 ? "tr.up" : "tr.down", { n: Math.abs(sh) });
    grid.innerHTML = v.map(function (c, n) {
      var on = c.ids.indexOf(sel) >= 0;
      return '<button type="button" class="ca-chord' + (on ? " sel" : "") + (c.label === "N.C." ? " nc" : "") + '" data-n="' + n + '" data-id="' + c.ids[0] + '">' +
        '<span class="ca-name">' + c.label + '</span><span class="ca-time">' + mmss(c.start) + "</span></button>";
    }).join("");
    grid.querySelectorAll(".ca-chord").forEach(function (b) {
      b.addEventListener("click", function () { pick(+b.dataset.id, true); });
    });
    playing = -1; tick(true);
    editRow.hidden = sel < 0;
    if (sel >= 0) {
      var s = segs[sel];
      fillRoots();
      rootSel.value = s.root < 0 ? "-1" : String((s.root + shift() + 120) % 12);
      qualSel.value = s.q;
      qualSel.disabled = s.root < 0;
    }
  }
  function fillRoots() {
    var names = useFlat() ? FLAT : SHARP;
    rootSel.innerHTML = '<option value="-1">N.C.</option>' + names.map(function (n, i) { return '<option value="' + i + '">' + n + "</option>"; }).join("");
  }
  function pick(id, seek) {
    sel = id;
    if (seek && segs[id]) { audio.currentTime = segs[id].start + 0.01; }
    render();
  }
  // 再生中のコードを大きく出す
  function tick(force) {
    if (!segs.length) return;
    var t = audio.currentTime || 0, v = view(), n = -1;
    for (var i = 0; i < v.length; i++) if (t >= v[i].start && t < v[i].end) { n = i; break; }
    if (loopEl.checked && sel >= 0 && !audio.paused) {
      var s = segs[sel];
      if (t >= s.end || t < s.start - 0.3) { audio.currentTime = s.start; }
    }
    if (n === playing && !force) return;
    playing = n;
    grid.querySelectorAll(".ca-chord").forEach(function (b) { b.classList.toggle("now", +b.dataset.n === n); });
    cur.textContent = n >= 0 ? v[n].label : "—";
    next.textContent = n >= 0 && v[n + 1] ? T("ca.next", { c: v[n + 1].label }) : "";
    var nowBtn = grid.querySelector(".ca-chord.now");
    if (nowBtn && !audio.paused) {
      var r = nowBtn.getBoundingClientRect(), g = grid.getBoundingClientRect();
      if (r.top < g.top || r.bottom > g.bottom) grid.scrollTop += r.top - g.top - 8;
    }
  }
  function loop() { tick(false); if (!audio.paused) requestAnimationFrame(loop); }
  audio.addEventListener("play", function () { requestAnimationFrame(loop); });
  audio.addEventListener("seeked", function () { tick(true); });
  audio.addEventListener("timeupdate", function () { if (audio.paused) tick(false); });

  // ---- ファイルを読む → 22050Hz・モノラルにする → 裏で解析 ----
  async function decode(f) {
    var Ctx = window.AudioContext || window.webkitAudioContext;
    var ac = new Ctx(), buf = await f.arrayBuffer();
    var a = await new Promise(function (ok, ng) { var p = ac.decodeAudioData(buf, ok, ng); if (p && p.then) p.then(ok, ng); });
    try { ac.close(); } catch (e) {}
    if (a.duration > 15 * 60) throw new Error("long");
    var off = new OfflineAudioContext(1, Math.ceil(a.duration * 22050), 22050);
    var src = off.createBufferSource(); src.buffer = a; src.connect(off.destination); src.start();
    var r = await off.startRendering();
    return r.getChannelData(0);
  }
  async function start(f) {
    if (!f) return;
    segs = []; sel = -1; key = null; result.hidden = true; t0 = performance.now();
    if (url) URL.revokeObjectURL(url);
    url = URL.createObjectURL(f); audio.src = url;
    $("ca-filename").textContent = f.name;
    setStatus(T("ca.decoding"), null);
    var y;
    try { y = await decode(f); }
    catch (e) { setStatus(e && e.message === "long" ? T("ca.tooLong", { n: 15 }) : T("ca.error"), null); return; }
    if (worker) worker.terminate();
    worker = new Worker(BASE + "chordworker.js");
    worker.onmessage = function (e) {
      var m = e.data;
      if (m.type === "progress") {
        var pct = Math.round(m.p * 100);
        setStatus(T("ca." + m.stage, { p: pct }), m.p);
      } else if (m.type === "done") {
        key = m.key;
        flatEl.checked = FLAT_MAJ.indexOf(majTonic()) >= 0;
        segs = m.segs.map(function (s) {
          var mm = /^([A-G][#b]?)(?::(\w+))?$/.exec(s.label);
          return mm ? { start: s.start, end: s.end, root: pc(mm[1]), q: mm[2] || "maj" } : { start: s.start, end: s.end, root: -1, q: "maj" };
        });
        shiftEl.value = 0;
        result.hidden = false;
        setStatus(T("ca.done", { n: view().length, sec: ((performance.now() - t0) / 1000).toFixed(1) }), null);
        render();
      } else {
        setStatus(T("ca.error"), null);
      }
    };
    worker.onerror = function () { setStatus(T("ca.error"), null); };
    worker.postMessage({ y: y }, [y.buffer]);
  }
  function pc(n) { var b = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 }[n[0]]; if (n[1] === "#") b++; if (n[1] === "b") b--; return (b + 12) % 12; }

  file.addEventListener("change", function () { start(file.files[0]); });
  ["dragenter", "dragover"].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add("over"); }); });
  ["dragleave", "drop"].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove("over"); }); });
  drop.addEventListener("drop", function (e) { var f = e.dataTransfer && e.dataTransfer.files[0]; if (f) start(f); });

  // ---- 表示の切りかえ・手直し ----
  document.querySelectorAll("[data-ca-shift]").forEach(function (b) {
    b.addEventListener("click", function () {
      shiftEl.value = Math.max(-11, Math.min(11, shift() + parseInt(b.dataset.caShift, 10)));
      render();
    });
  });
  [shiftEl, flatEl, simpleEl, degEl].forEach(function (el) { el.addEventListener("input", render); el.addEventListener("change", render); });
  qualSel.innerHTML = QUAL.map(function (q) { return '<option value="' + q + '">' + (SFX[q] || T("ca.majName")) + "</option>"; }).join("");
  rootSel.addEventListener("change", function () {
    if (sel < 0) return;
    var r = parseInt(rootSel.value, 10);
    segs[sel].root = r < 0 ? -1 : (r - shift() + 120) % 12;
    render();
  });
  qualSel.addEventListener("change", function () { if (sel >= 0) { segs[sel].q = qualSel.value; render(); } });
  $("ca-merge").addEventListener("click", function () {
    if (sel <= 0) return;
    segs[sel - 1].end = segs[sel].end; segs.splice(sel, 1); sel--; render();
  });
  $("ca-split").addEventListener("click", function () {
    if (sel < 0) return;
    var s = segs[sel], t = audio.currentTime;
    if (!(t > s.start + 0.2 && t < s.end - 0.2)) { t = (s.start + s.end) / 2; }
    segs.splice(sel + 1, 0, { start: t, end: s.end, root: s.root, q: s.q }); s.end = t; sel++; render();
  });
  function text() { return view().map(function (c) { return ASCII(c.label); }).join(" "); }
  $("ca-copy").addEventListener("click", function () {
    var t = text(), done = function () { $("ca-copy-msg").textContent = T("ca.copied"); setTimeout(function () { $("ca-copy-msg").textContent = ""; }, 2000); };
    if (navigator.clipboard) navigator.clipboard.writeText(t).then(done, function () {}); else done();
  });
  $("ca-to-tr").addEventListener("click", function () {
    var t = view().filter(function (c) { return c.label !== "N.C."; }).map(function (c) { return ASCII(c.label); });
    if (degEl.checked) { degEl.checked = false; t = view().filter(function (c) { return c.label !== "N.C."; }).map(function (c) { return ASCII(c.label); }); degEl.checked = true; }
    location.href = "transpose.html?c=" + encodeURIComponent(t.join(" "));
  });
  // ← → キーで前後のコードへ（入力中でないとき）
  document.addEventListener("keydown", function (e) {
    if (!segs.length || /INPUT|SELECT|TEXTAREA/.test((e.target.tagName || ""))) return;
    if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
      var v = view(), n = playing >= 0 ? playing : 0;
      n = Math.max(0, Math.min(v.length - 1, n + (e.key === "ArrowRight" ? 1 : -1)));
      pick(v[n].ids[0], true); e.preventDefault();
    }
  });
})();
