// おとけい 5周目（スピーカーケーブル・電源容量・マイク感度・テンポとフレーム）
(function () {
  "use strict";
  const K = window.OTK;
  if (!K) return;
  const { $, num, fmt, on, T, LANG, saved } = K;

  // ---------- スピーカーケーブルのロス ----------
  function cable() {
    const len = $("cb-len");
    if (!len) return;
    const size = $("cb-size"), z = $("cb-z"), df = $("cb-df");
    const RHO = 0.0172; // 銅の抵抗率 Ω·mm²/m
    const r = () => {
      const L = num(len), A = parseFloat(size.value), Z = parseFloat(z.value), D = num(df);
      const set = (id, v) => { $(id).textContent = v; };
      if (!(L >= 0) || !(A > 0) || !(Z > 0)) { ["cb-db", "cb-r", "cb-loss", "cb-max", "cb-dfout"].forEach((id) => set(id, "—")); return; }
      const R = 2 * L * RHO / A;
      const db = 20 * Math.log10(Z / (Z + R));
      set("cb-db", (db < -0.005 ? "−" : "") + fmt(Math.abs(db), 2));
      set("cb-r", fmt(R, 3));
      set("cb-loss", fmt(R / (Z + R) * 100, 1));
      // 0.5dB以内に収まる長さ
      const rMax = Z * (Math.pow(10, 0.5 / 20) - 1);
      set("cb-max", fmt(rMax * A / (2 * RHO), 0));
      set("cb-dfout", D > 0 ? fmt(Z / (8 / D + R), 0) : "—");
    };
    on([len, size, z, df], "input", r);
    on([size, z], "change", r);
    r();
  }

  // ---------- 電源容量 ----------
  function power() {
    const list = $("pw-list");
    if (!list) return;
    const v = $("pw-v"), a = $("pw-a");
    // 国ごとのふつうの電圧とブレーカー（まだ自分で選んでいないときだけ）
    const DEF = { ja: [100, 15], en: [120, 15], "zh-Hant": [110, 15], ko: [220, 16], "zh-Hans": [220, 16], id: [220, 16], "pt-BR": [127, 15] };
    if (saved("pw-v") === undefined && saved("pw-a") === undefined) {
      const d = DEF[LANG] || [230, 16];
      v.value = String(d[0]); a.value = String(d[1]);
    }
    const r = () => {
      const ws = list.value.split(/[,、，;；\s]+/).map((s) => parseFloat(s.replace(/[^\d.\-]/g, ""))).filter((x) => x > 0);
      const V = parseFloat(v.value), B = num(a);
      if (!ws.length || !(V > 0)) { $("pw-amp").textContent = "—"; $("pw-w").textContent = "—"; $("pw-msg").textContent = ""; $("pw-cap").textContent = "—"; return; }
      const W = ws.reduce((x, y) => x + y, 0);
      const I = W / V;
      $("pw-amp").textContent = fmt(I, 1);
      $("pw-w").textContent = fmt(W, 0);
      if (B > 0) {
        const p = I / B * 100;
        const key = p > 100 ? "pw.over" : p > 80 ? "pw.warn" : "pw.ok";
        $("pw-msg").textContent = T(key, { p: fmt(p, 0) });
        $("pw-msg").className = "result-line" + (p > 100 ? " error" : "");
        $("pw-cap").textContent = fmt(V * B * 0.8, 0);
      } else { $("pw-msg").textContent = ""; $("pw-cap").textContent = "—"; }
    };
    on([list, a], "input", r);
    on([v], "change", r);
    r();
  }

  // ---------- マイク感度とゲイン ----------
  function mic() {
    const val = $("mc-val");
    if (!val) return;
    const unit = $("mc-unit"), spl = $("mc-spl"), tgt = $("mc-target");
    const dbvOf = () => {
      const x = num(val);
      if (unit.value === "mv") return x > 0 ? 20 * Math.log10(x / 1000) : NaN;
      return isFinite(x) ? x : NaN;
    };
    const sign = (x, d) => (x < 0 ? "−" : x > 0 ? "+" : "") + fmt(Math.abs(x), d);
    const r = () => {
      const s = dbvOf();
      if (!isFinite(s)) { ["mc-other", "mc-dbv", "mc-dbu", "mc-mvout", "mc-gain"].forEach((id) => { $(id).textContent = "—"; }); return; }
      if (unit.value === "mv") { $("mc-other").textContent = sign(s, 1); $("mc-other-u").textContent = "dBV/Pa"; }
      else { $("mc-other").textContent = fmt(Math.pow(10, s / 20) * 1000, 2); $("mc-other-u").textContent = "mV/Pa"; }
      const L = num(spl);
      if (!isFinite(L)) { ["mc-dbv", "mc-dbu", "mc-mvout", "mc-gain"].forEach((id) => { $(id).textContent = "—"; }); return; }
      const out = s + (L - 94);
      const dbu = out + 2.2185;
      $("mc-dbv").textContent = sign(out, 1);
      $("mc-dbu").textContent = sign(dbu, 1);
      $("mc-mvout").textContent = fmt(Math.pow(10, out / 20) * 1000, 2);
      const t = num(tgt);
      $("mc-gain").textContent = isFinite(t) ? fmt(t - dbu, 0) : "—";
    };
    // 単位を切りかえたら、同じ感度のまま数字を変換する
    let last = unit.value;
    unit.addEventListener("change", () => {
      const x = num(val);
      if (last === "mv" && unit.value === "dbv" && x > 0) val.value = (20 * Math.log10(x / 1000)).toFixed(1);
      if (last === "dbv" && unit.value === "mv" && isFinite(x)) val.value = (Math.pow(10, x / 20) * 1000).toFixed(2);
      last = unit.value; r();
    });
    document.querySelectorAll("[data-mv]").forEach((b) => b.addEventListener("click", () => {
      const mv = parseFloat(b.dataset.mv);
      val.value = unit.value === "mv" ? String(mv) : (20 * Math.log10(mv / 1000)).toFixed(1);
      r();
    }));
    document.querySelectorAll("[data-spl]").forEach((b) => b.addEventListener("click", () => { spl.value = b.dataset.spl; r(); }));
    on([val, spl, tgt], "input", r);
    r();
  }

  // ---------- テンポとフレーム（タイムコードのページ） ----------
  function tempoFrames() {
    const bpm = $("tf-bpm"), sel = $("tc-fps");
    if (!bpm || !sel) return;
    const real = () => {
      const v = sel.value;
      if (v.startsWith("23.976")) return 24000 / 1001;
      if (v.startsWith("29.97")) return 30000 / 1001;
      if (v.startsWith("59.94")) return 60000 / 1001;
      return parseFloat(v);
    };
    const r = () => {
      const b = num(bpm), f = real();
      if (!(b > 0) || !(f > 0)) { $("tf-beat").textContent = "—"; $("tf-bar").textContent = "—"; return; }
      const beat = 60 / b * f;
      $("tf-beat").textContent = fmt(beat, 2);
      $("tf-bar").textContent = fmt(beat * 4, 2);
    };
    on([bpm], "input", r);
    sel.addEventListener("change", r);
    r();
  }

  document.addEventListener("DOMContentLoaded", () => { cable(); power(); mic(); tempoFrames(); });
})();
