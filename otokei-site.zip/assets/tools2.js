// おとけい 追加ツール（チューナー・コード・スケール・倍音・音響・PA など）
(function () {
  "use strict";
  const K = window.OTK;
  if (!K) return;
  const { $, num, fmt, ok, on, audio, blip, piano, SHARP, FLAT, nameOf, yamahaOf, freqOf, T } = K;

  const FLAT_KEYS = [5, 10, 3, 8, 1, 6]; // F, B♭, E♭, A♭, D♭, G♭ は♭で書く
  const spell = (pc, flat) => (flat ? FLAT : SHARP)[((pc % 12) + 12) % 12].replace("b", "♭").replace("#", "♯");
  const rootOptions = (sel) => {
    const labels = T("keys.labels").split(",");
    sel.innerHTML = labels.map((l, i) => `<option value="${i}">${l}</option>`).join("");
    const v = K.saved && K.saved(sel.id); if (v !== undefined) sel.value = v;
  };

  // 小さな鍵盤（コード・スケール用）。marks に入っている音を光らせる
  function miniKeyboard(el, low, count, marks, onPress) {
    const whites = [], blacks = [];
    let wi = 0;
    const nWhite = Array.from({ length: count }, (_, i) => low + i).filter((m) => ![1, 3, 6, 8, 10].includes(m % 12)).length;
    el.style.gridTemplateColumns = `repeat(${nWhite}, 1fr)`;
    for (let m = low; m < low + count; m++) {
      const isBlack = [1, 3, 6, 8, 10].includes(m % 12);
      const mk = marks.has(m) ? " on" : "";
      if (isBlack) {
        blacks.push(`<button type="button" class="key black${mk}" data-m="${m}" style="left:calc(${wi} * (100% / ${nWhite}) - (100% / ${nWhite}) * 0.3);width:calc(100% / ${nWhite} * 0.6)" aria-label="${nameOf(m)}"></button>`);
      } else {
        const label = m % 12 === 0 ? `<span>${nameOf(m)}</span>` : "";
        whites.push(`<button type="button" class="key white${mk}" data-m="${m}" aria-label="${nameOf(m)}">${label}</button>`);
        wi++;
      }
    }
    el.innerHTML = whites.join("") + blacks.join("");
    el.querySelectorAll(".key").forEach((k) => k.addEventListener("pointerdown", (e) => {
      e.preventDefault();
      const m = +k.dataset.m;
      piano(freqOf(m, 440), 0, 1.4, 0.55);
      if (onPress) onPress(m);
    }));
  }
  const playNotes = (midis, arp) => {
    const c = audio(); if (!c) return;
    const t = c.currentTime + 0.03;
    midis.forEach((m, i) => piano(freqOf(m, 440), arp ? t + i * 0.22 : t, arp ? 0.6 : 1.8, arp ? 0.5 : 0.32));
    if (arp) {
      const end = t + midis.length * 0.22 + 0.05;
      midis.forEach((m) => piano(freqOf(m, 440), end, 1.8, 0.3));
    }
  };

  // ---------- コード表 ----------
  const CHORDS = [
    ["", [0, 4, 7]], ["m", [0, 3, 7]], ["7", [0, 4, 7, 10]],
    ["M7", [0, 4, 7, 11]], ["m7", [0, 3, 7, 10]],
    ["mM7", [0, 3, 7, 11]], ["6", [0, 4, 7, 9]], ["m6", [0, 3, 7, 9]],
    ["sus2", [0, 2, 7]], ["sus4", [0, 5, 7]], ["7sus4", [0, 5, 7, 10]],
    ["add9", [0, 4, 7, 14]], ["9", [0, 4, 7, 10, 14]], ["M9", [0, 4, 7, 11, 14]],
    ["m9", [0, 3, 7, 10, 14]], ["dim", [0, 3, 6]], ["dim7", [0, 3, 6, 9]],
    ["m7(♭5)", [0, 3, 6, 10]], ["aug", [0, 4, 8]]
  ];
  const INTERVAL = (i) => T("iv." + i);
  // コードの構成音を、度数に合った音名で書く（例：Cm の短3度は D♯ ではなく E♭）
  const LETTERS = ["C", "D", "E", "F", "G", "A", "B"], LETTER_PC = [0, 2, 4, 5, 7, 9, 11];
  const DEGREE = { 0: 0, 1: 1, 2: 1, 3: 2, 4: 2, 5: 3, 6: 4, 7: 4, 8: 4, 9: 5, 10: 6, 11: 6, 13: 1, 14: 1, 15: 1 };
  const toneName = (rootName, i, suffix) => {
    const li = LETTERS.indexOf(rootName[0]);
    const acc = rootName.slice(1);
    const rootPc = (LETTER_PC[li] + (acc === "♯" ? 1 : acc === "♭" ? -1 : 0) + 12) % 12;
    const deg = suffix === "dim7" && i === 9 ? 6 : (DEGREE[i] ?? 0);
    const L = (li + deg) % 7;
    let d = ((rootPc + i - LETTER_PC[L]) % 12 + 12) % 12; if (d > 6) d -= 12;
    return LETTERS[L] + (d > 0 ? "♯".repeat(d) : "♭".repeat(-d));
  };
  function chord() {
    const rootSel = $("ch-root");
    if (!rootSel) return;
    const typeSel = $("ch-type");
    rootOptions(rootSel);
    typeSel.innerHTML = CHORDS.map(([s], i) => `<option value="${i}">${s || T("chord.none")}${T("gap")}${T("chord.n" + i)}</option>`).join("");
    if (K.saved("ch-type") !== undefined) typeSel.value = K.saved("ch-type");
    let current = [];
    const render = () => {
      const r = +rootSel.value, [suffix, iv] = CHORDS[+typeSel.value], jname = T("chord.n" + typeSel.value);
      const flat = FLAT_KEYS.includes(r);
      const rootName = spell(r, flat);
      $("ch-name").textContent = rootName + suffix;
      $("ch-jname").textContent = jname;
      const base = 48 + r; // ルートをC3〜B3に置く
      current = iv.map((i) => base + i);
      $("ch-notes").innerHTML = iv.map((i) => {
        const label = suffix === "dim7" && i === 9 ? T("iv.dim7") : INTERVAL(i);
        return `<span class="chip">${toneName(rootName, i, suffix)}<small>${label}</small></span>`;
      }).join("");
      miniKeyboard($("ch-kb"), 48, 29, new Set(current));
    };
    on([rootSel, typeSel], "change", render);
    $("ch-play").addEventListener("click", () => playNotes(current, false));
    $("ch-arp").addEventListener("click", () => playNotes(current, true));
    render();
  }

  // ---------- スケールとダイアトニックコード ----------
  const SCALES = [
    ["scale.n0", [0, 2, 4, 5, 7, 9, 11]], ["scale.n1", [0, 2, 3, 5, 7, 8, 10]],
    ["scale.n2", [0, 2, 3, 5, 7, 8, 11]], ["scale.n3", [0, 2, 3, 5, 7, 9, 11]],
    ["scale.n4", [0, 2, 4, 7, 9]], ["scale.n5", [0, 3, 5, 7, 10]], ["scale.n6", [0, 3, 5, 6, 7, 10]],
    ["scale.n7", [0, 2, 3, 5, 7, 9, 10]], ["scale.n8", [0, 1, 3, 5, 7, 8, 10]], ["scale.n9", [0, 2, 4, 6, 7, 9, 11]],
    ["scale.n10", [0, 2, 4, 5, 7, 9, 10]]
  ];
  const ROMAN = ["Ⅰ", "Ⅱ", "Ⅲ", "Ⅳ", "Ⅴ", "Ⅵ", "Ⅶ"];
  const triadName = (a, b) => ({ "4,7": "", "3,7": "m", "3,6": "dim", "4,8": "aug" })[`${a},${b}`];
  const seventhName = (a, b, c) => ({
    "4,7,11": "M7", "4,7,10": "7", "3,7,10": "m7", "3,6,10": "m7(♭5)", "3,6,9": "dim7", "3,7,11": "mM7", "4,8,11": "aug(M7)", "4,8,10": "aug7"
  })[`${a},${b},${c}`];
  function scale() {
    const rootSel = $("sc-root");
    if (!rootSel) return;
    const typeSel = $("sc-type");
    rootOptions(rootSel);
    typeSel.innerHTML = SCALES.map(([n], i) => `<option value="${i}">${T(n)}</option>`).join("");
    if (K.saved("sc-type") !== undefined) typeSel.value = K.saved("sc-type");
    let current = [];
    const render = () => {
      const r = +rootSel.value, [skey, iv] = SCALES[+typeSel.value], sname = T(skey);
      const minorish = iv[2] === 3;
      // ♭で書くキー：長調は F B♭ E♭ A♭ D♭ G♭、短調は D G C F B♭ E♭
      const flat = minorish ? [2, 7, 0, 5, 10, 3].includes(r) : FLAT_KEYS.includes(r);
      $("sc-name").textContent = `${spell(r, flat)} ${sname}`;
      current = iv.map((i) => 48 + r + i).concat([60 + r]);
      $("sc-notes").innerHTML = iv.map((i) => `<span class="chip">${spell(r + i, flat)}</span>`).join("");
      miniKeyboard($("sc-kb"), 48, 29, new Set(current));
      const box = $("sc-chords");
      if (iv.length !== 7) { box.innerHTML = `<p class="note">${T("scale.noDiatonic")}</p>`; return; }
      const rows = iv.map((_, d) => {
        const n = [0, 2, 4, 6].map((k) => iv[(d + k) % 7] + (d + k >= 7 ? 12 : 0));
        const rel = n.map((x) => x - n[0]);
        const root = spell(r + n[0], flat);
        const t = triadName(rel[1], rel[2]), s = seventhName(rel[1], rel[2], rel[3]);
        return `<tr><td>${ROMAN[d]}</td><td class="chordcell">${t === undefined ? "—" : root + t}</td><td class="chordcell">${s === undefined ? "—" : root + s}</td></tr>`;
      });
      box.innerHTML = `<div class="table-scroll"><table><thead><tr><th>${T("scale.degree")}</th><th>${T("scale.triad")}</th><th>${T("scale.seventh")}</th></tr></thead><tbody>${rows.join("")}</tbody></table></div>`;
    };
    on([rootSel, typeSel], "change", render);
    $("sc-play").addEventListener("click", () => {
      const c = audio(); if (!c) return;
      const t = c.currentTime + 0.03;
      current.forEach((m, i) => piano(freqOf(m, 440), t + i * 0.25, 0.5, 0.5));
    });
    render();
  }

  // ---------- 倍音 ----------
  function harmonics() {
    const fIn = $("hm-freq");
    if (!fIn) return;
    const render = () => {
      const f = num(fIn);
      if (!(f > 0)) { $("hm-table").innerHTML = ""; return; }
      const rows = [];
      for (let n = 1; n <= 16; n++) {
        const h = f * n;
        if (h > 22000) break;
        const exact = 69 + 12 * Math.log2(h / 440), m = Math.round(exact), c = Math.round((exact - m) * 100);
        const w = Math.max(2, 100 / n);
        rows.push(`<tr${n === 1 ? ' class="hl"' : ""}><td>${n === 1 ? T("hm.fund") : T("hm.nth", { n })}<span class="bar" style="width:${w}%"></span></td>` +
          `<td class="num">${fmt(h, h < 1000 ? 1 : 0)}</td><td>${m >= 0 && m <= 127 ? nameOf(m) : "—"}</td>` +
          `<td class="num">${c === 0 ? "±0" : (c > 0 ? "+" : "") + c}</td></tr>`);
      }
      $("hm-table").innerHTML = rows.join("");
    };
    fIn.addEventListener("input", render);
    document.querySelectorAll("[data-hm]").forEach((b) => b.addEventListener("click", () => { fIn.value = b.dataset.hm; render(); }));
    K.stepper(fIn, render);
    render();
  }

  // ---------- チューナー（マイク） ----------
  // 自己相関でいちばん強いくり返しの長さを探す
  function detectPitch(buf, sr) {
    let size = buf.length, rms = 0;
    for (let i = 0; i < size; i++) rms += buf[i] * buf[i];
    rms = Math.sqrt(rms / size);
    if (rms < 0.01) return -1;
    let r1 = 0, r2 = size - 1;
    const th = 0.2;
    for (let i = 0; i < size / 2; i++) if (Math.abs(buf[i]) < th) { r1 = i; break; }
    for (let i = 1; i < size / 2; i++) if (Math.abs(buf[size - i]) < th) { r2 = size - i; break; }
    buf = buf.slice(r1, r2); size = buf.length;
    const c = new Float32Array(size);
    for (let i = 0; i < size; i++) { let s = 0; for (let j = 0; j < size - i; j++) s += buf[j] * buf[j + i]; c[i] = s; }
    let d = 0; while (d < size - 1 && c[d] > c[d + 1]) d++;
    let max = -1, pos = -1;
    for (let i = d; i < size; i++) if (c[i] > max) { max = c[i]; pos = i; }
    if (pos <= 0 || pos >= size - 1) return -1;
    const x1 = c[pos - 1], x2 = c[pos], x3 = c[pos + 1];
    const a = (x1 + x3 - 2 * x2) / 2, b = (x3 - x1) / 2;
    const per = a ? pos - b / (2 * a) : pos;
    return sr / per;
  }
  K.detectPitch = detectPitch;
  function tuner() {
    const btn = $("tu-start");
    if (!btn) return;
    let stream = null, raf = 0, analyser = null, buf = null, smooth = null;
    const a4 = $("tu-a4");
    const needle = $("tu-needle");
    const stop = () => {
      cancelAnimationFrame(raf);
      if (stream) stream.getTracks().forEach((t) => t.stop());
      stream = null; btn.textContent = T("mic.on"); btn.setAttribute("aria-pressed", "false");
    };
    const loop = () => {
      analyser.getFloatTimeDomainData(buf);
      const f = detectPitch(buf, K.getCtx().sampleRate);
      if (f > 25 && f < 4500) {
        smooth = smooth ? smooth * 0.7 + f * 0.3 : f;
        const ref = num(a4) || 440;
        const exact = 69 + 12 * Math.log2(smooth / ref), m = Math.round(exact), cents = (exact - m) * 100;
        $("tu-note").textContent = nameOf(m);
        $("tu-sub").textContent = [K.solf(m), `${fmt(smooth, 1)} Hz`].filter(Boolean).join(T("gap"));
        const c = Math.round(cents);
        $("tu-cent").textContent = c === 0 ? T("cent.exact") : T(c > 0 ? "cent.plainSharp" : "cent.plainFlat", { c: Math.abs(c) });
        needle.style.transform = `rotate(${Math.max(-50, Math.min(50, cents)) * 0.9}deg)`;
        $("tu-meter").classList.toggle("good", Math.abs(cents) < 5);
      }
      raf = requestAnimationFrame(loop);
    };
    btn.addEventListener("click", async () => {
      if (stream) { stop(); return; }
      const c = audio();
      if (!c || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        $("tu-error").textContent = T("mic.unsupported"); return;
      }
      try {
        stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false } });
      } catch (e) {
        $("tu-error").textContent = T("mic.denied"); return;
      }
      $("tu-error").textContent = "";
      const srcNode = c.createMediaStreamSource(stream);
      analyser = c.createAnalyser(); analyser.fftSize = 4096;
      buf = new Float32Array(analyser.fftSize);
      srcNode.connect(analyser);
      smooth = null;
      btn.textContent = T("mic.off"); btn.setAttribute("aria-pressed", "true");
      loop();
    });
  }

  // ---------- 距離と音量 ----------
  function distance() {
    const d1 = $("ds-d1");
    if (!d1) return;
    const l1 = $("ds-l1"), d2 = $("ds-d2"), type = $("ds-type");
    const render = () => {
      const a = num(d1), b = num(d2), L = num(l1);
      if (!(a > 0) || !(b > 0) || !isFinite(L)) { $("ds-out").textContent = "—"; $("ds-diff").textContent = ""; return; }
      const k = type.value === "line" ? 10 : 20;
      const diff = -k * Math.log10(b / a);
      $("ds-out").textContent = fmt(L + diff, 1);
      $("ds-diff").textContent = T("ds.diff", { d: `${diff >= 0 ? "+" : ""}${fmt(diff, 1)}` });
    };
    on([d1, l1, d2], "input", render); type.addEventListener("change", render);
    render();
  }

  // ---------- 距離と遅延（タイムアライメント） ----------
  const soundSpeed = (t) => 331.5 + 0.61 * t;
  function align() {
    const dIn = $("al-dist");
    if (!dIn) return;
    const tIn = $("al-temp"), msIn = $("al-ms");
    const r1 = () => {
      const d = num(dIn), t = num(tIn);
      if (!(d >= 0) || !ok(t, -50, 60)) { $("al-out").textContent = "—"; return; }
      const ms = d / soundSpeed(t) * 1000;
      $("al-out").textContent = fmt(ms, 2);
      $("al-smp").textContent = T("al.smp", { n: fmt(ms * 48, 0) });
      $("al-comb").textContent = ms > 0 ? `${fmt(1000 / (2 * ms), 0)} Hz` : "—";
    };
    const r2 = () => {
      const ms = num(msIn), t = num(tIn);
      if (!(ms >= 0) || !ok(t, -50, 60)) { $("al-back").textContent = "—"; return; }
      const m = ms / 1000 * soundSpeed(t);
      $("al-back").textContent = m >= 1 ? `${fmt(m, 2)} m` : `${fmt(m * 100, 1)} cm`;
    };
    on([dIn, tIn], "input", r1); on([msIn, tIn], "input", r2);
    r1(); r2();
  }

  // ---------- 部屋の定在波（ルームモード） ----------
  function room() {
    const L = $("rm-l");
    if (!L) return;
    const W = $("rm-w"), H = $("rm-h"), Tin = $("rm-t");
    const render = () => {
      const dims = [[T("room.depth"), num(L)], [T("room.width"), num(W)], [T("room.height"), num(H)]];
      const c = soundSpeed(num(Tin));
      if (dims.some(([, v]) => !(v > 0)) || !isFinite(c)) { $("rm-table").innerHTML = ""; return; }
      const modes = [];
      dims.forEach(([name, v]) => { for (let n = 1; n <= 6; n++) { const f = n * c / (2 * v); if (f <= 300) modes.push({ f, name, n }); } });
      modes.sort((a, b) => a.f - b.f);
      $("rm-table").innerHTML = modes.map((m, i) => {
        const near = modes.some((o, j) => j !== i && o.name !== m.name && Math.abs(o.f - m.f) / m.f < 0.05);
        return `<tr${near ? ' class="hl"' : ""}><td class="num">${fmt(m.f, 1)}</td><td>${T("room.order", { name: m.name, n: m.n })}</td><td>${near ? T("room.near") : ""}</td></tr>`;
      }).join("");
    };
    on([L, W, H, Tin], "input", render);
    render();
  }

  // ---------- スピーカーの合成インピーダンス ----------
  function impedance() {
    const list = $("im-list");
    if (!list) return;
    const mode = $("im-mode");
    const render = () => {
      const vals = list.value.split(/[\s,、，]+/).map(parseFloat).filter((v) => v > 0);
      if (!vals.length) { $("im-out").textContent = "—"; $("im-warn").textContent = ""; return; }
      const z = mode.value === "series" ? vals.reduce((a, v) => a + v, 0) : 1 / vals.reduce((a, v) => a + 1 / v, 0);
      $("im-out").textContent = fmt(z, 2);
      $("im-warn").textContent = z < 4 ? T("im.warn") : "";
    };
    list.addEventListener("input", render); mode.addEventListener("change", render);
    render();
  }

  // ---------- dBu・dBV・電圧 ----------
  function dbu() {
    const v = $("du-val");
    if (!v) return;
    const unit = $("du-unit");
    const render = () => {
      const x = num(v);
      let volts;
      if (unit.value === "dbu") volts = 0.7746 * Math.pow(10, x / 20);
      else if (unit.value === "dbv") volts = Math.pow(10, x / 20);
      else volts = x;
      if (!(volts > 0) || !isFinite(volts)) { ["du-dbu", "du-dbv", "du-v"].forEach((id) => $(id).textContent = "—"); return; }
      $("du-dbu").textContent = fmt(20 * Math.log10(volts / 0.7746), 2);
      $("du-dbv").textContent = fmt(20 * Math.log10(volts), 2);
      $("du-v").textContent = volts < 0.01 ? fmt(volts * 1000, 2) + " mV" : fmt(volts, 3) + " V";
    };
    v.addEventListener("input", render); unit.addEventListener("change", render);
    document.querySelectorAll("[data-du]").forEach((b) => b.addEventListener("click", () => {
      const [val, u] = b.dataset.du.split("|"); v.value = val; unit.value = u; render();
    }));
    render();
  }

  // ---------- 録音できる時間・ビット深度 ----------
  function recTime() {
    const gb = $("rt-gb");
    if (!gb) return;
    const sr = $("rt-sr"), bits = $("rt-bits"), ch = $("rt-ch");
    const render = () => {
      const bytesPerSec = num(sr) * num(bits) / 8 * num(ch);
      const sec = num(gb) * 1e9 / bytesPerSec;
      if (!(sec > 0)) { $("rt-out").textContent = "—"; return; }
      const h = Math.floor(sec / 3600), m = Math.floor((sec - h * 3600) / 60);
      $("rt-out").textContent = T("time.hm", { h, m });
    };
    on([gb], "input", render); on([sr, bits, ch], "change", render);
    render();
    const bd = $("bd-bits"), bsr = $("bd-sr");
    const r2 = () => {
      const b = num(bd);
      $("bd-dr").textContent = fmt(6.02 * b + 1.76, 1);
      $("bd-ny").textContent = fmt(num(bsr) / 2000, 2);
    };
    on([bd, bsr], "change", r2); r2();
  }

  // ---------- ホームの検索 ----------
  function search() {
    const q = $("tool-search");
    if (!q) return;
    q.addEventListener("input", () => {
      const s = q.value.trim().toLowerCase();
      document.querySelectorAll(".app").forEach((a) => {
        a.hidden = s && !(a.textContent + " " + (a.dataset.k || "")).toLowerCase().includes(s);
      });
      document.querySelectorAll(".cat").forEach((c) => {
        c.hidden = !c.querySelector(".app:not([hidden])");
      });
      $("no-hit").hidden = !!document.querySelector(".app:not([hidden])");
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    chord(); scale(); harmonics(); tuner(); distance(); align(); room(); impedance(); dbu(); recTime(); search();
  });
})();
