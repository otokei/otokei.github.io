// おとけい 4周目（ディグリー変換・音程と周波数比・スピーカーのカバー範囲・BPM→BPM・サンプリングレートのまちがい）
(function () {
  "use strict";
  const K = window.OTK;
  if (!K) return;
  const { $, num, fmt, ok, on, T } = K;

  const idx = (r) => {
    const map = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
    let n = map[r[0]];
    for (const ch of r.slice(1)) {
      if (ch === "#" || ch === "♯") n += 1;
      if (ch === "b" || ch === "♭") n -= 1;
    }
    return ((n % 12) + 12) % 12;
  };

  // ---------- ディグリー（ローマ数字）変換 ----------
  const ROMAN = ["Ⅰ", "♭Ⅱ", "Ⅱ", "♭Ⅲ", "Ⅲ", "Ⅳ", "♯Ⅳ", "Ⅴ", "♭Ⅵ", "Ⅵ", "♭Ⅶ", "Ⅶ"];
  function degree() {
    const keySel = $("dg-key");
    if (!keySel) return;
    const modeSel = $("dg-mode"), prog = $("dg-prog");
    keySel.innerHTML = T("keys.labels").split(",").map((l, i) => `<option value="${i}">${l}</option>`).join("");
    const sv = K.saved("dg-key"); keySel.value = sv !== undefined ? sv : "0";
    const render = () => {
      const k = +keySel.value, minor = modeSel.value === "minor";
      // 短調のときは、その短調の主音（ラ）を Ⅰ として数える
      const tonic = k;
      const tokens = prog.value.trim().split(/\s+/).filter(Boolean);
      $("dg-out").innerHTML = tokens.map((t) => {
        const m = t.match(/^([A-G](?:[#b♯♭])?)(.*?)(?:\/([A-G](?:[#b♯♭])?))?$/);
        if (!m) return `<span class="chip muted">${t}</span>`;
        const d = (idx(m[1]) - tonic + 12) % 12;
        const bass = m[3] ? "/" + ROMAN[(idx(m[3]) - tonic + 12) % 12] : "";
        return `<span class="chip">${ROMAN[d]}${m[2]}${bass}<small>${t}</small></span>`;
      }).join("");
      $("dg-note").textContent = minor ? T("dg.minorNote") : "";
    };
    on([keySel, modeSel], "change", render); prog.addEventListener("input", render);
    render();
  }

  // ---------- 音程と周波数比 ----------
  function interval() {
    const f1 = $("iv-f1");
    if (!f1) return;
    const f2 = $("iv-f2"), cents = $("iv-cents");
    const nameOfSemis = (s) => {
      const oct = Math.floor(s / 12), r = s % 12;
      const base = T("ivn." + r);
      if (s === 12) return T("ivn.12");
      return oct > 0 ? T("ivn.plusOct", { name: base, n: oct }) : base;
    };
    const r1 = () => {
      const a = num(f1), b = num(f2);
      if (!(a > 0) || !(b > 0)) { $("iv-out").textContent = "—"; return; }
      const lo = Math.min(a, b), hi = Math.max(a, b);
      const c = 1200 * Math.log2(hi / lo);
      const s = Math.round(c / 100), dev = Math.round(c - s * 100);
      $("iv-out").textContent = fmt(c, 1);
      $("iv-ratio").textContent = fmt(hi / lo, 4);
      $("iv-name").textContent = nameOfSemis(s) + (dev === 0 ? "" : T("iv.dev", { d: `${dev > 0 ? "+" : "−"}${Math.abs(dev)}` }));
    };
    const r2 = () => {
      const c = num(cents);
      $("iv-ratio2").textContent = isFinite(c) ? fmt(Math.pow(2, c / 1200), 5) : "—";
    };
    on([f1, f2], "input", r1); cents.addEventListener("input", r2);
    document.querySelectorAll("[data-ivc]").forEach((b) => b.addEventListener("click", () => { cents.value = b.dataset.ivc; r2(); }));
    r1(); r2();
  }

  // ---------- スピーカーのカバー範囲 ----------
  function coverage() {
    const ang = $("cv-angle");
    if (!ang) return;
    const dist = $("cv-dist"), wid = $("cv-width"), dist2 = $("cv-dist2");
    const r1 = () => {
      const a = num(ang), d = num(dist);
      if (!ok(a, 1, 179) || !(d > 0)) { $("cv-out").textContent = "—"; return; }
      const w = 2 * d * Math.tan(a / 2 * Math.PI / 180);
      $("cv-out").textContent = fmt(w, 1);
      // 図：角度に合わせて扇形を描く
      const half = Math.min(80, a / 2) * Math.PI / 180, L = 120;
      $("cv-fan").setAttribute("d", `M20 70 L${20 + L * Math.cos(half)} ${70 - L * Math.sin(half)} L${20 + L * Math.cos(half)} ${70 + L * Math.sin(half)} Z`);
    };
    const r2 = () => {
      const w = num(wid), d = num(dist2);
      $("cv-need").textContent = (w > 0 && d > 0) ? fmt(2 * Math.atan(w / 2 / d) * 180 / Math.PI, 0) : "—";
    };
    on([ang, dist], "input", r1); on([wid, dist2], "input", r2);
    document.querySelectorAll("[data-angle]").forEach((b) => b.addEventListener("click", () => { ang.value = b.dataset.angle; r1(); }));
    r1(); r2();
  }

  // ---------- BPM → BPM ----------
  function bpm2bpm() {
    const a = $("bb-from");
    if (!a) return;
    const b = $("bb-to");
    const r = () => {
      const x = num(a), y = num(b);
      if (!(x > 0) || !(y > 0)) { $("bb-pct").textContent = "—"; $("bb-semi").textContent = "—"; return; }
      $("bb-pct").textContent = fmt(y / x * 100, 2);
      const st = 12 * Math.log2(y / x);
      $("bb-semi").textContent = `${st >= 0 ? "+" : "−"}${fmt(Math.abs(st), 2)}`;
    };
    on([a, b], "input", r);
    r();
  }

  // ---------- サンプリングレートのまちがい ----------
  function srMismatch() {
    const file = $("sm-file");
    if (!file) return;
    const play = $("sm-play");
    const r = () => {
      const f = num(file), p = num(play);
      const ratio = p / f;
      $("sm-pct").textContent = fmt(ratio * 100, 2);
      const st = 12 * Math.log2(ratio);
      $("sm-semi").textContent = Math.abs(st) < 0.005 ? "±0" : `${st >= 0 ? "+" : "−"}${fmt(Math.abs(st), 2)}`;
      $("sm-len").textContent = fmt(1 / ratio * 100, 2);
    };
    on([file, play], "change", r);
    r();
  }

  // 図の中の文字が帯や左の欄からはみ出す言語では、文字を小さくして収める（それでも無理なら隠す。帯をさわれば全文が出る）
  function fitChartLabels() {
    document.querySelectorAll("svg.eqchart").forEach((svg) => {
      const texts = [...svg.querySelectorAll("text")];
      let left = Infinity;
      texts.forEach((t) => {
        const prev = t.previousElementSibling;
        if (prev && prev.tagName === "rect") {
          const room = parseFloat(prev.getAttribute("width")) - 6;
          let fs = parseFloat(t.getAttribute("font-size"));
          while (t.getComputedTextLength() > room && fs > 8) { fs -= 0.5; t.setAttribute("font-size", fs); }
          if (t.getComputedTextLength() > room) t.style.display = "none";
          left = Math.min(left, parseFloat(prev.getAttribute("x")));
        }
      });
      texts.forEach((t) => {
        if (t.getAttribute("x") !== "0" || !isFinite(left)) return;
        let fs = parseFloat(t.getAttribute("font-size"));
        while (t.getComputedTextLength() > left - 6 && fs > 9) { fs -= 0.5; t.setAttribute("font-size", fs); }
      });
    });
  }

  document.addEventListener("DOMContentLoaded", () => { degree(); interval(); coverage(); bpm2bpm(); srMismatch(); fitChartLabels(); });
})();
