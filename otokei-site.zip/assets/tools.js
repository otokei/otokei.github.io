// おとけい｜音づくりの計算ツール  計算・音はすべてこのファイル（ブラウザの中だけで動く）
(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  // 言語：<html lang="…"> を使う。文は言語ごとの辞書（msgs.js）から出す
  const LANG = document.documentElement.lang || "ja";
  const MSG = window.OTK_MSG || {};
  const T = (k, v) => {
    let s = MSG[k];
    if (s === undefined) s = k;
    if (v) {
      // {n|semitone|semitones} のように、数が1のときと、それ以外のときで言葉を変えられる
      s = s.replace(/\{(\w+)\|([^|}]*)\|([^}]*)\}/g, (all, name, one, other) => (v[name] !== undefined ? (Number(v[name]) === 1 ? one : other) : all));
      s = s.replace(/\{(\w+)\}/g, (all, name) => (v[name] !== undefined ? v[name] : all));
    }
    return s;
  };
  const num = (el) => parseFloat(String(el.value).replace(",", "."));
  const fmt = (v, d) => {
    if (!isFinite(v)) return "—";
    return v.toLocaleString(LANG, { minimumFractionDigits: d, maximumFractionDigits: d });
  };
  const ok = (v, min, max) => isFinite(v) && v >= min && v <= max;
  const on = (els, ev, fn) => els.forEach((e) => e && e.addEventListener(ev, fn));

  // ---------- 音を鳴らす共通部分（ボタンを押したときだけ動く） ----------
  let ctx = null;
  const audio = () => {
    if (!ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    }
    if (ctx.state === "suspended") ctx.resume();
    return ctx;
  };
  // 短い音（ピアノ鍵盤・メトロノームで使う）
  const blip = (freq, when, len, vol, type) => {
    const c = audio(); if (!c) return;
    const t = when || c.currentTime;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type || "triangle";
    o.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0001, t + len);
    o.connect(g).connect(c.destination);
    o.start(t); o.stop(t + len + 0.02);
  };

  // ピアノらしい音：弦の倍音（高い倍音ほど早く消え、少し高めにずれる）・2本の弦のうなり・ハンマーの「コツ」・小さな部屋の響き
  let pianoBus = null, noiseBuf = null;
  const pianoOut = (c) => {
    if (pianoBus) return pianoBus;
    const dry = c.createGain(), wet = c.createGain(), comp = c.createDynamicsCompressor();
    dry.gain.value = 1; wet.gain.value = 0.08;
    // 響き：短いノイズをだんだん小さくしたものを残響として使う
    const len = Math.floor(c.sampleRate * 1.6), ir = c.createBuffer(2, len, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const d = ir.getChannelData(ch);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3.2);
    }
    const rev = c.createConvolver(); rev.buffer = ir;
    comp.threshold.value = -14; comp.ratio.value = 3;
    const inp = c.createGain();
    inp.connect(dry); inp.connect(rev); rev.connect(wet);
    dry.connect(comp); wet.connect(comp); comp.connect(c.destination);
    pianoBus = inp;
    return inp;
  };
  const synthPiano = (freq, when, len, vol) => {
    const c = audio(); if (!c) return;
    const t = (when || c.currentTime) + 0.005;
    const out = pianoOut(c);
    const note = c.createGain(), lp = c.createBiquadFilter();
    note.gain.value = vol || 0.3;
    lp.type = "lowpass"; lp.Q.value = 0.3;
    lp.frequency.setValueAtTime(Math.min(12000, freq * 14), t);
    lp.frequency.setTargetAtTime(Math.min(6000, freq * 4), t, 0.25);
    note.connect(lp).connect(out);
    const sustain = Math.min(9, Math.max(0.8, 7 * Math.pow(110 / freq, 0.6))); // 低い音ほど長く鳴る
    const B = 0.00025; // 弦の硬さで倍音が少し高くずれる
    const end = t + len, stopAt = end + 0.6;
    const parts = [];
    for (let n = 1; n <= 12 && n * freq < 14000; n++) {
      const a = Math.pow(n, -1.15) * (0.25 + 0.75 * Math.abs(Math.sin(Math.PI * n / 7.5)));
      parts.push([n, a]);
    }
    const total = parts.reduce((s, p) => s + p[1], 0);
    parts.forEach(([n, a]) => {
      const f = n * freq * Math.sqrt(1 + B * n * n);
      const amp = a / total;
      const tau = sustain / (1 + 0.55 * (n - 1));
      [-1, 1].forEach((side) => { // 1つの鍵盤に弦が2本：ほんの少しずらしてうなりを作る
        if (n > 4 && side > 0) return;
        const o = c.createOscillator(), g = c.createGain();
        o.frequency.value = f; o.detune.value = side * (0.8 + n * 0.15);
        const peak = n > 4 ? amp : amp / 2;
        g.gain.setValueAtTime(0.0001, t);
        g.gain.linearRampToValueAtTime(peak, t + 0.003);
        g.gain.setTargetAtTime(peak * 0.4, t + 0.003, 0.06 + 0.25 / n); // 打った直後に少し落ちる
        g.gain.setTargetAtTime(0.00001, t + 0.12, tau);                  // そのあとゆっくり消える
        g.gain.setTargetAtTime(0.00001, end, 0.07);                      // 鍵盤を離すとダンパーで止まる
        o.connect(g).connect(note);
        o.start(t); o.stop(stopAt);
      });
    });
    // ハンマーが弦をたたく短い音
    if (!noiseBuf) {
      noiseBuf = c.createBuffer(1, Math.floor(c.sampleRate * 0.05), c.sampleRate);
      const d = noiseBuf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    }
    const ns = c.createBufferSource(), bp = c.createBiquadFilter(), ng = c.createGain();
    ns.buffer = noiseBuf; bp.type = "bandpass"; bp.frequency.value = Math.min(3500, freq * 5); bp.Q.value = 1.2;
    ng.gain.setValueAtTime(0.12, t); ng.gain.exponentialRampToValueAtTime(0.0001, t + 0.04);
    ns.connect(bp).connect(ng).connect(note);
    ns.start(t); ns.stop(t + 0.05);
  };

  // 録音したピアノ（Salamander Grand Piano／Alexander Holm／CC BY 3.0）。短3度おきの録音の高さをずらして全部の鍵盤を出す
  const PIANO_BASE = (() => { try { return new URL("piano/", (document.currentScript && document.currentScript.src) || location.href).href; } catch (e) { return "piano/"; } })();
  const PNAMES = ["A", "C", "Ds", "Fs"];
  const sampleOf = (midi) => {
    let m = Math.round((midi - 21) / 3) * 3 + 21;
    m = Math.max(21, Math.min(108, m));
    const name = PNAMES[((m - 21) / 3) % 4] + Math.floor((m - 12) / 12);
    return { m, name };
  };
  const pianoBufs = {};
  const loadSample = (name) => {
    if (pianoBufs[name]) return pianoBufs[name];
    const c = audio();
    pianoBufs[name] = fetch(PIANO_BASE + name + ".mp3")
      .then((r) => { if (!r.ok) throw new Error("no sample"); return r.arrayBuffer(); })
      .then((ab) => new Promise((res, rej) => c.decodeAudioData(ab, res, rej)))
      .catch(() => { pianoBufs[name] = null; return null; });
    return pianoBufs[name];
  };
  // ピアノを使うページでは、最初にどこかをさわった時点でよく使う高さの録音を先に読んでおく
  const preloadPiano = () => { for (let m = 45; m <= 84; m += 3) loadSample(sampleOf(m).name); };
  const piano = (freq, when, len, vol) => {
    const c = audio(); if (!c) return;
    const midi = 69 + 12 * Math.log2(freq / 440);
    const { m, name } = sampleOf(midi);
    const want = when || c.currentTime;
    Promise.resolve(loadSample(name)).then((buf) => {
      if (!buf) { synthPiano(freq, Math.max(want, c.currentTime), len, vol); return; } // 読めないときは作った音で代わりに鳴らす
      const t = Math.max(want, c.currentTime + 0.01);
      const src = c.createBufferSource(), g = c.createGain();
      src.buffer = buf;
      src.playbackRate.value = freq / (440 * Math.pow(2, (m - 69) / 12));
      g.gain.value = (vol || 0.3) * 2.4;
      g.gain.setValueAtTime((vol || 0.3) * 2.4, t + len);
      g.gain.setTargetAtTime(0.0001, t + len, 0.12); // 鍵盤を離すとダンパーで止まる
      src.connect(g).connect(pianoOut(c));
      src.start(t);
      src.stop(t + len + 1);
    });
  };
  if (/(note|chord|scale)\.html/.test(location.pathname)) {
    const once = () => { preloadPiano(); document.removeEventListener("pointerdown", once); };
    document.addEventListener("pointerdown", once);
  }

  // ---------- 音名の共通部分 ----------
  const SHARP = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
  const FLAT = ["C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B"];
  // ドレミ（その言語で使う呼び方。使わない言語では空）
  const SOLF = T("solfege") && T("solfege") !== "solfege" ? T("solfege").split(",") : null;
  const solf = (m) => (SOLF ? SOLF[m % 12] : "");
  const nameOf = (m) => `${SHARP[m % 12]}${Math.floor(m / 12) - 1}`;   // 国際式（C4 = MIDI 60）
  const yamahaOf = (m) => `${SHARP[m % 12]}${Math.floor(m / 12) - 2}`; // ヤマハ式（C3 = MIDI 60）
  const freqOf = (m, a4) => a4 * Math.pow(2, (m - 69) / 12);

  // ---------- BPM → ディレイ・リバーブ時間 ----------
  const NOTES = [
    [T("note.whole"), 4], [T("note.half"), 2], [T("note.quarter"), 1], [T("note.8th"), 0.5],
    [T("note.16th"), 0.25], [T("note.32nd"), 0.125]
  ];
  function delay() {
    const bpmEl = $("bpm");
    if (!bpmEl || !$("delay-table")) return;
    const render = () => {
      const bpm = num(bpmEl);
      const body = $("delay-table");
      const err = $("bpm-error");
      if (!ok(bpm, 1, 999)) {
        err.textContent = T("delay.bpmError");
        body.innerHTML = "";
        $("quarter-ms").textContent = "—";
        return;
      }
      err.textContent = "";
      const q = 60000 / bpm;
      $("quarter-ms").textContent = fmt(q, 1);
      body.innerHTML = NOTES.map(([name, beats]) => {
        const n = q * beats;
        const hl = beats === 1 ? ' class="hl"' : "";
        const w = Math.max(1.5, beats / 4 * 100); // 全音符を100%とした棒の長さ
        return `<tr${hl}><td>${name}<span class="bar" style="width:${w}%"></span></td>` +
          `<td class="num">${fmt(n, 1)}</td>` +
          `<td class="num">${fmt(n * 1.5, 1)}</td><td class="num">${fmt(n * 2 / 3, 1)}</td>` +
          `<td class="num hz">${fmt(1000 / n, 2)}</td></tr>`;
      }).join("");
    };
    bpmEl.addEventListener("input", render);
    document.addEventListener("bpmchange", (e) => { bpmEl.value = e.detail; render(); });
    stepper(bpmEl, render);
    render();
  }

  // 数字の横の −／＋ ボタン
  function stepper(input, after) {
    const box = input.closest(".field");
    if (!box) return;
    box.querySelectorAll("[data-step]").forEach((b) => {
      b.addEventListener("click", () => {
        const step = parseFloat(b.dataset.step);
        const v = (num(input) || 0) + step;
        const min = parseFloat(input.min), max = parseFloat(input.max);
        input.value = Math.round(Math.min(isFinite(max) ? max : v, Math.max(isFinite(min) ? min : v, v)) * 100) / 100;
        input.dispatchEvent(new Event("change"));
        after();
      });
    });
  }

  // ---------- タップテンポ ----------
  function tap() {
    const btn = $("tap-btn");
    if (!btn) return;
    let times = [];
    const out = $("tap-bpm");
    const count = $("tap-count");
    const hit = () => {
      const now = performance.now();
      if (times.length && now - times[times.length - 1] > 2500) times = [];
      times.push(now);
      if (times.length > 12) times.shift();
      btn.classList.remove("pulse"); void btn.offsetWidth; btn.classList.add("pulse");
      if (times.length < 2) {
        out.textContent = "—";
        count.textContent = T("tap.again");
        return;
      }
      const avg = (times[times.length - 1] - times[0]) / (times.length - 1);
      const bpm = 60000 / avg;
      out.textContent = fmt(bpm, 1);
      count.textContent = T("tap.count", { n: times.length });
      document.dispatchEvent(new CustomEvent("bpmchange", { detail: Math.round(bpm * 10) / 10 }));
    };
    btn.addEventListener("pointerdown", (e) => { e.preventDefault(); hit(); });
    btn.addEventListener("keydown", (e) => {
      if (e.key === " " || e.key === "Enter") { e.preventDefault(); hit(); }
    });
    const reset = $("tap-reset");
    if (reset) reset.addEventListener("click", () => {
      times = []; out.textContent = "—"; count.textContent = "";
    });
  }

  // ---------- メトロノーム ----------
  function metronome() {
    const bpmEl = $("met-bpm");
    if (!bpmEl) return;
    const beatsEl = $("met-beats"), subEl = $("met-sub"), btn = $("met-start"), dots = $("met-dots");
    let timer = null, next = 0, step = 0, queue = [];
    const drawDots = () => {
      const n = parseInt(beatsEl.value, 10);
      dots.innerHTML = Array.from({ length: n }, (_, i) => `<span class="dot${i === 0 ? " first" : ""}"></span>`).join("");
    };
    const tick = () => {
      const c = ctx;
      const bpm = num(bpmEl);
      if (!ok(bpm, 20, 400)) return;
      const n = parseInt(beatsEl.value, 10), sub = parseInt(subEl.value, 10);
      while (next < c.currentTime + 0.12) {
        const beat = Math.floor(step / sub) % n, isBeat = step % sub === 0;
        if (isBeat) blip(beat === 0 ? 1600 : 1000, next, 0.05, beat === 0 ? 0.5 : 0.3, "square");
        else blip(800, next, 0.03, 0.12, "square"); // 拍の間の小さいクリック
        if (isBeat) queue.push({ t: next, b: beat });
        next += 60 / bpm / sub;
        step++;
      }
    };
    const paint = () => {
      if (!timer) return;
      while (queue.length && queue[0].t <= ctx.currentTime) {
        const { b } = queue.shift();
        dots.querySelectorAll(".dot").forEach((d, i) => d.classList.toggle("lit", i === b));
      }
      requestAnimationFrame(paint);
    };
    const stop = () => {
      clearInterval(timer); timer = null; queue = [];
      btn.textContent = T("btn.start"); btn.setAttribute("aria-pressed", "false");
      dots.querySelectorAll(".dot").forEach((d) => d.classList.remove("lit"));
    };
    btn.addEventListener("click", () => {
      if (timer) { stop(); return; }
      if (!audio()) { $("met-error").textContent = T("err.noAudio"); return; }
      step = 0; next = ctx.currentTime + 0.06;
      timer = setInterval(tick, 25); tick();
      requestAnimationFrame(paint);
      btn.textContent = T("btn.stop"); btn.setAttribute("aria-pressed", "true");
    });
    beatsEl.addEventListener("change", () => { drawDots(); step = 0; });
    subEl.addEventListener("change", () => { step = 0; });
    stepper(bpmEl, () => {});
    // タップでテンポを合わせる
    let taps = [];
    const tapBtn = $("met-tap");
    tapBtn.addEventListener("click", () => {
      const now = performance.now();
      if (taps.length && now - taps[taps.length - 1] > 2500) taps = [];
      taps.push(now); if (taps.length > 8) taps.shift();
      if (taps.length >= 2) {
        const bpm = 60000 / ((taps[taps.length - 1] - taps[0]) / (taps.length - 1));
        bpmEl.value = Math.round(Math.min(400, Math.max(20, bpm)));
        bpmEl.dispatchEvent(new Event("input"));
      }
    });
    drawDots();
  }

  // ---------- テスト音（サイン波・ノイズ） ----------
  const noiseBuffer = (c, pink) => {
    const len = c.sampleRate * 4, buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (let i = 0; i < len; i++) {
      const w = Math.random() * 2 - 1;
      if (!pink) { d[i] = w * 0.5; continue; }
      // ピンクノイズ（Paul Kelletの近似フィルター）
      b0 = 0.99886 * b0 + w * 0.0555179; b1 = 0.99332 * b1 + w * 0.0750759;
      b2 = 0.96900 * b2 + w * 0.1538520; b3 = 0.86650 * b3 + w * 0.3104856;
      b4 = 0.55000 * b4 + w * 0.5329522; b5 = -0.7616 * b5 - w * 0.0168980;
      d[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + w * 0.5362) * 0.11;
      b6 = w * 0.115926;
    }
    return buf;
  };
  function tone() {
    const fIn = $("tone-freq");
    if (!fIn) return;
    const slider = $("tone-slider"), wave = $("tone-wave"), vol = $("tone-vol"), btn = $("tone-play");
    let src = null, gain = null, bufs = {};
    const sweepTimerRef = () => $("tone-sweep") && $("tone-sweep").getAttribute("aria-pressed") === "true";
    const isNoise = () => wave.value === "white" || wave.value === "pink";
    const toSlider = (f) => Math.round(Math.log10(f / 20) / 3 * 1000);
    const fromSlider = (s) => 20 * Math.pow(10, s / 1000 * 3);
    const level = () => Math.pow(num(vol) / 100, 2) * 0.5;
    const apply = () => {
      const f = num(fIn);
      $("tone-freq-box").style.opacity = isNoise() ? 0.35 : 1;
      if (!sweepTimerRef() && src && src.frequency && f > 0) src.frequency.setTargetAtTime(Math.min(20000, Math.max(20, f)), ctx.currentTime, 0.01);
      if (gain) gain.gain.setTargetAtTime(level(), ctx.currentTime, 0.02);
    };
    const startSrc = () => {
      const c = audio(); if (!c) return false;
      if (!gain) { gain = c.createGain(); gain.gain.value = 0; gain.connect(c.destination); }
      if (isNoise()) {
        const k = wave.value;
        bufs[k] = bufs[k] || noiseBuffer(c, k === "pink");
        src = c.createBufferSource(); src.buffer = bufs[k]; src.loop = true;
      } else {
        src = c.createOscillator(); src.type = wave.value; src.frequency.value = Math.min(20000, Math.max(20, num(fIn) || 440));
      }
      src.connect(gain); src.start();
      return true;
    };
    const stopSrc = () => { if (src) { const s = src; setTimeout(() => { try { s.stop(); } catch (e) {} }, 80); src = null; } };
    fIn.addEventListener("input", () => { const f = num(fIn); if (f > 0) slider.value = toSlider(f); apply(); });
    slider.addEventListener("input", () => {
      const f = fromSlider(num(slider));
      fIn.value = f < 100 ? f.toFixed(1) : Math.round(f);
      apply();
    });
    vol.addEventListener("input", apply);
    wave.addEventListener("change", () => {
      apply();
      if (src) { stopSrc(); startSrc(); }
    });
    document.querySelectorAll("[data-freq]").forEach((b) => b.addEventListener("click", () => {
      fIn.value = b.dataset.freq; slider.value = toSlider(num(fIn)); apply();
    }));
    btn.addEventListener("click", () => {
      if (src) {
        gain.gain.setTargetAtTime(0, ctx.currentTime, 0.02);
        stopSrc();
        btn.textContent = T("btn.play"); btn.setAttribute("aria-pressed", "false");
        return;
      }
      if (!startSrc()) return;
      apply();
      btn.textContent = T("btn.stopSound"); btn.setAttribute("aria-pressed", "true");
    });
    // スイープ：20Hz → 20kHz（対数）を決まった秒数で上げる
    const sweepBtn = $("tone-sweep"), sweepSec = $("tone-sweep-sec");
    let sweepTimer = 0;
    const endSweep = () => {
      cancelAnimationFrame(sweepTimer); sweepTimer = 0;
      sweepBtn.textContent = T("btn.sweep"); sweepBtn.setAttribute("aria-pressed", "false");
    };
    sweepBtn.addEventListener("click", () => {
      if (sweepTimer) { // 止める
        if (src) { gain.gain.setTargetAtTime(0, ctx.currentTime, 0.02); stopSrc(); btn.textContent = T("btn.play"); btn.setAttribute("aria-pressed", "false"); }
        endSweep(); return;
      }
      if (isNoise()) { wave.value = "sine"; }
      if (src) stopSrc();
      if (!startSrc()) return;
      const dur = Math.max(2, num(sweepSec) || 20);
      const t0 = ctx.currentTime;
      src.frequency.cancelScheduledValues(t0);
      src.frequency.setValueAtTime(20, t0);
      src.frequency.exponentialRampToValueAtTime(20000, t0 + dur);
      apply();
      // apply() がずらさないように周波数の入力を毎フレーム合わせる
      btn.textContent = T("btn.stopSound"); btn.setAttribute("aria-pressed", "true");
      sweepBtn.textContent = T("btn.stopSweep"); sweepBtn.setAttribute("aria-pressed", "true");
      const tick = () => {
        const p = (ctx.currentTime - t0) / dur;
        if (p >= 1 || !src) {
          if (src) { gain.gain.setTargetAtTime(0, ctx.currentTime, 0.02); stopSrc(); }
          btn.textContent = T("btn.play"); btn.setAttribute("aria-pressed", "false");
          endSweep(); return;
        }
        const f = 20 * Math.pow(1000, p);
        fIn.value = f < 100 ? f.toFixed(1) : Math.round(f);
        slider.value = toSlider(f);
        sweepTimer = requestAnimationFrame(tick);
      };
      sweepTimer = requestAnimationFrame(tick);
    });
    btn.addEventListener("click", () => { if (sweepTimer) endSweep(); });
    slider.value = toSlider(num(fIn));
    apply();
  }

  // ---------- dB計算 ----------
  function db() {
    const dbIn = $("db-in");
    if (!dbIn) return;
    const r1 = () => {
      const d = num(dbIn);
      if (!ok(d, -200, 200)) { $("db-v").textContent = "—"; $("db-p").textContent = "—"; return; }
      const v = Math.pow(10, d / 20), p = Math.pow(10, d / 10);
      $("db-v").textContent = v >= 1000 ? fmt(v, 1) : fmt(v, v < 0.01 ? 5 : 3);
      $("db-p").textContent = p >= 1000 ? fmt(p, 1) : fmt(p, p < 0.01 ? 6 : 3);
      // 棒：元の大きさを25%として、変えたあとの電圧（音圧）の大きさ
      $("db-bar-after").style.width = Math.min(100, Math.max(0.5, 25 * v)) + "%";
      $("db-bar-after").classList.toggle("over", 25 * v > 100);
    };
    dbIn.addEventListener("input", r1); stepper(dbIn, r1); r1();

    const ratioIn = $("ratio-in"), ratioType = $("ratio-type");
    const r2 = () => {
      const r = num(ratioIn);
      if (!(r > 0) || !isFinite(r)) { $("ratio-db").textContent = "—"; return; }
      const k = ratioType.value === "power" ? 10 : 20;
      $("ratio-db").textContent = fmt(k * Math.log10(r), 2);
    };
    ratioIn.addEventListener("input", r2); ratioType.addEventListener("change", r2); r2();

    const sumIn = $("sum-in");
    const r3 = () => {
      const vals = sumIn.value.split(/[\s,、，]+/).map((s) => parseFloat(s)).filter((v) => isFinite(v));
      if (vals.length < 2) { $("sum-out").textContent = "—"; $("sum-n").textContent = T("db.needTwo"); return; }
      const total = 10 * Math.log10(vals.reduce((a, v) => a + Math.pow(10, v / 10), 0));
      $("sum-out").textContent = fmt(total, 1);
      $("sum-n").textContent = T("db.count", { n: vals.length });
    };
    sumIn.addEventListener("input", r3); r3();
  }

  // ---------- 音名と周波数（押すと鳴る鍵盤つき） ----------
  function note() {
    const a4 = $("a4");
    if (!a4) return;
    const fIn = $("freq-in"), kb = $("keyboard");
    let low = 48; // 鍵盤の左はし（C3）
    const showKey = (m) => {
      const ref = num(a4);
      $("key-name").textContent = nameOf(m);
      $("key-sub").textContent = [T("note.yamaha", { name: yamahaOf(m) }), solf(m), `MIDI ${m}`].filter(Boolean).join(T("sep"));
      $("key-freq").textContent = fmt(freqOf(m, ref), 2);
      kb.querySelectorAll(".key").forEach((k) => k.classList.toggle("on", +k.dataset.m === m));
    };
    const drawKeys = () => {
      const whites = [], blacks = [];
      let wi = 0;
      for (let m = low; m < low + 24; m++) {
        const isBlack = [1, 3, 6, 8, 10].includes(m % 12);
        if (isBlack) {
          blacks.push(`<button type="button" class="key black" data-m="${m}" style="left:calc(${wi} * (100% / 14) - (100% / 14) * 0.3)" aria-label="${nameOf(m)}"></button>`);
        } else {
          const label = m % 12 === 0 ? `<span>${nameOf(m)}</span>` : "";
          whites.push(`<button type="button" class="key white" data-m="${m}" aria-label="${nameOf(m)}">${label}</button>`);
          wi++;
        }
      }
      kb.innerHTML = whites.join("") + blacks.join("");
      kb.querySelectorAll(".key").forEach((k) => k.addEventListener("pointerdown", (e) => {
        e.preventDefault();
        const m = +k.dataset.m;
        piano(freqOf(m, num(a4)), 0, 1.6, 0.6);
        showKey(m);
      }));
      $("oct-label").textContent = T("range", { a: nameOf(low), b: nameOf(low + 23) });
    };
    $("oct-down").addEventListener("click", () => { if (low > 24) { low -= 12; drawKeys(); } });
    $("oct-up").addEventListener("click", () => { if (low < 84) { low += 12; drawKeys(); } });

    const renderTable = () => {
      const ref = num(a4);
      if (!ok(ref, 400, 480)) { $("a4-error").textContent = T("note.a4Error"); return; }
      $("a4-error").textContent = "";
      const rows = [];
      for (let m = 21; m <= 108; m++) {
        const hl = m === 69 ? ' class="hl"' : "";
        rows.push(`<tr${hl}><td>${nameOf(m)}</td><td>${yamahaOf(m)}</td><td class="solf">${solf(m)}</td>` +
          `<td class="num">${m}</td><td class="num">${fmt(freqOf(m, ref), 2)}</td></tr>`);
      }
      $("note-table").innerHTML = rows.join("");
      renderFreq();
      showKey(69);
    };
    const renderFreq = () => {
      const ref = num(a4), f = num(fIn);
      if (!(f > 0) || !ok(ref, 400, 480)) { $("freq-note").textContent = "—"; $("freq-cent").textContent = ""; return; }
      const exact = 69 + 12 * Math.log2(f / ref);
      const m = Math.round(exact);
      const c = Math.round((exact - m) * 100);
      if (m < 0 || m > 127) { $("freq-note").textContent = T("note.outOfRange"); $("freq-cent").textContent = ""; return; }
      $("freq-note").textContent = T("note.withYamaha", { name: nameOf(m), yamaha: yamahaOf(m) });
      $("freq-cent").textContent = c === 0 ? T("cent.exact") : T(c > 0 ? "cent.sharp" : "cent.flat", { c: Math.abs(c) });
    };
    a4.addEventListener("input", renderTable);
    fIn.addEventListener("input", renderFreq);
    drawKeys();
    renderTable();
  }

  // ---------- キー・コードの移調 ----------
  function transpose() {
    const input = $("tr-in");
    if (!input) return;
    const stepEl = $("tr-step"), useFlat = $("tr-flat");
    const idx = (r) => {
      const map = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
      let n = map[r[0]];
      if (r[1] === "#" || r[1] === "♯") n += 1;
      if (r[1] === "b" || r[1] === "♭") n -= 1;
      return (n + 12) % 12;
    };
    const shiftRoot = (r, s) => (useFlat.checked ? FLAT : SHARP)[(idx(r) + s + 120) % 12];
    const shiftChord = (ch, s) =>
      ch.replace(/^([A-G][#b♯♭]?)(.*?)(?:\/([A-G][#b♯♭]?))?$/, (all, root, rest, bass) =>
        shiftRoot(root, s) + rest + (bass ? "/" + shiftRoot(bass, s) : ""));
    const render = () => {
      const s = parseInt(stepEl.value, 10) || 0;
      $("tr-step-label").textContent = s === 0 ? T("tr.same") : T(s > 0 ? "tr.up" : "tr.down", { n: Math.abs(s) });
      const tokens = input.value.trim().split(/\s+/).filter(Boolean);
      if (!tokens.length) { $("tr-out").innerHTML = ""; return; }
      $("tr-out").innerHTML = tokens.map((t) =>
        /^[A-G]/.test(t) ? `<span class="chip">${shiftChord(t, s)}</span>` : `<span class="chip muted">${t}</span>`
      ).join("");
    };
    document.querySelectorAll("[data-tr]").forEach((b) => b.addEventListener("click", () => {
      const v = Math.max(-11, Math.min(11, (parseInt(stepEl.value, 10) || 0) + parseInt(b.dataset.tr, 10)));
      stepEl.value = v; render();
    }));
    on([input, stepEl], "input", render);
    useFlat.addEventListener("change", render);
    render();
  }

  // ---------- 再生速度とピッチ ----------
  function speed() {
    const sp = $("sp-in");
    if (!sp) return;
    const semi = $("semi-in"), bpm = $("sp-bpm");
    const r1 = () => {
      const r = num(sp) / 100;
      if (!(r > 0)) { $("sp-semi").textContent = "—"; $("sp-newbpm").textContent = "—"; return; }
      const st = 12 * Math.log2(r);
      $("sp-semi").textContent = `${st > 0 ? "+" : ""}${fmt(st, 2)}`;
      const b = num(bpm);
      $("sp-newbpm").textContent = b > 0 ? fmt(b * r, 1) : "—";
    };
    const r2 = () => {
      const s = num(semi);
      if (!ok(s, -48, 48)) { $("semi-sp").textContent = "—"; return; }
      $("semi-sp").textContent = fmt(Math.pow(2, s / 12) * 100, 2);
    };
    on([sp, bpm], "input", r1); semi.addEventListener("input", r2);
    stepper(sp, r1); stepper(semi, r2);
    r1(); r2();
  }

  // ---------- 録音ファイルの容量 ----------
  function filesize() {
    const fmtSel = $("fs-format");
    if (!fmtSel) return;
    const sr = $("fs-sr"), bits = $("fs-bits"), ch = $("fs-ch"), kbps = $("fs-kbps"), mm = $("fs-min"), ss = $("fs-sec");
    const render = () => {
      const isWav = fmtSel.value === "wav";
      $("fs-wav-opts").hidden = !isWav;
      $("fs-mp3-opts").hidden = isWav;
      const sec = (num(mm) || 0) * 60 + (num(ss) || 0);
      if (!(sec > 0)) { $("fs-out").textContent = "—"; $("fs-unit").textContent = "MB"; $("fs-rate").textContent = ""; return; }
      let bytesPerSec;
      if (isWav) bytesPerSec = num(sr) * num(bits) / 8 * num(ch);
      else bytesPerSec = num(kbps) * 1000 / 8;
      const bytes = bytesPerSec * sec;
      const mb = bytes / 1e6;
      if (mb >= 1000) { $("fs-out").textContent = fmt(mb / 1000, 2); $("fs-unit").textContent = "GB"; }
      else { $("fs-out").textContent = fmt(mb, mb < 10 ? 2 : 1); $("fs-unit").textContent = "MB"; }
      $("fs-rate").textContent = T("fs.perMin", { mb: fmt(bytesPerSec * 60 / 1e6, 1) });
    };
    on([fmtSel, sr, bits, ch, kbps], "change", render);
    on([mm, ss], "input", render);
    render();
  }

  // ---------- サンプル数と時間 ----------
  function samples() {
    const sr = $("sr");
    if (!sr) return;
    const msIn = $("ms-in"), smpIn = $("smp-in");
    const r1 = () => {
      const s = num(sr), ms = num(msIn);
      $("ms-smp").textContent = (s > 0 && ms >= 0) ? fmt(ms * s / 1000, 0) : "—";
    };
    const r2 = () => {
      const s = num(sr), n = num(smpIn);
      $("smp-ms").textContent = (s > 0 && n >= 0) ? fmt(n / s * 1000, 3) : "—";
    };
    const bpm = $("bars-bpm"), bars = $("bars-n"), beats = $("bars-beats");
    const r3 = () => {
      const b = num(bpm), n = num(bars), per = num(beats);
      if (!ok(b, 1, 999) || !(n >= 0) || !ok(per, 1, 32)) { $("bars-sec").textContent = "—"; $("bars-mmss").textContent = ""; return; }
      const sec = n * per * 60 / b;
      $("bars-sec").textContent = fmt(sec, 2);
      const m = Math.floor(sec / 60), s2 = sec - m * 60;
      $("bars-mmss").textContent = T("time.ms", { m, s: fmt(s2, 1) });
    };
    on([sr], "change", () => { r1(); r2(); });
    on([msIn], "input", r1);
    on([smpIn], "input", r2);
    on([bpm, bars, beats], "input", r3);
    document.querySelectorAll("[data-buf]").forEach((b) => b.addEventListener("click", () => { smpIn.value = b.dataset.buf; r2(); }));
    r1(); r2(); r3();
  }

  // ---------- 波長 ----------
  function wave() {
    const fIn = $("wl-freq");
    if (!fIn) return;
    const tIn = $("wl-temp");
    const r = () => {
      const f = num(fIn), t = num(tIn);
      if (!ok(t, -50, 60)) { $("wl-c").textContent = "—"; $("wl-out").textContent = "—"; return; }
      const c = 331.5 + 0.61 * t;
      $("wl-c").textContent = fmt(c, 1);
      if (!(f > 0)) { $("wl-out").textContent = "—"; $("wl-half").textContent = "—"; $("wl-q").textContent = "—"; $("wl-like").textContent = ""; return; }
      const l = c / f;
      const show = (m) => m >= 1 ? `${fmt(m, 2)} m` : `${fmt(m * 100, 1)} cm`;
      $("wl-out").textContent = l >= 1 ? fmt(l, 2) : fmt(l * 100, 1);
      $("wl-unit").textContent = l >= 1 ? "m" : "cm";
      $("wl-half").textContent = show(l / 2);
      $("wl-q").textContent = show(l / 4);
      // 身近なものとくらべる
      const things = [[0.01, T("wl.t1"), 0.02], [0.1, T("wl.t2"), 0.07],
        [0.4, T("wl.t3"), 0.297], [1.2, T("wl.t4"), 1.7],
        [4, T("wl.t5"), 4.5], [12, T("wl.t6"), 11], [Infinity, T("wl.t7"), 25]];
      const hit = things.find(([lim]) => l < lim);
      const ratio = l / hit[2];
      $("wl-like").textContent = ratio >= 0.95 && ratio <= 1.05 ? T("wl.same", { thing: hit[1] }) : T("wl.ratio", { thing: hit[1], r: fmt(ratio, 1) });
      // 波の絵：1波長が何回見えるか（低い音ほど少なく）
      const cycles = Math.max(1, Math.min(8, Math.round(Math.log2(f / 20) + 1)));
      let d = "M0 40";
      for (let x = 0; x <= 600; x += 4) d += ` L${x} ${40 - 28 * Math.sin((x / 600) * cycles * 2 * Math.PI)}`;
      $("wl-path").setAttribute("d", d);
      const one = 600 / cycles;
      $("wl-span").setAttribute("x2", one);
      $("wl-span-end").setAttribute("x1", one); $("wl-span-end").setAttribute("x2", one);
      $("wl-span-label").setAttribute("x", one / 2);
    };
    on([fIn, tIn], "input", r);
    r();
  }

  // ---------- 入れた値を覚える（このブラウザの中だけ。使えないときは何もしない） ----------
  const KEY = "otokei:" + location.pathname.split("/").pop();
  const load = () => { try { return JSON.parse(localStorage.getItem(KEY) || "{}"); } catch (e) { return {}; } };
  const saved = (id) => load()[id];
  function remember() {
    const data = load();
    document.querySelectorAll("main input[id], main select[id]").forEach((el) => {
      if (el.id === "tool-search" || el.type === "range" && el.id === "tone-slider") return;
      if (data[el.id] !== undefined && el.options === undefined) {
        if (el.type === "checkbox") el.checked = !!data[el.id]; else el.value = data[el.id];
      } else if (data[el.id] !== undefined && el.options && el.options.length) {
        if ([...el.options].some((o) => o.value === String(data[el.id]))) el.value = data[el.id];
      }
      const save = () => {
        const d = load();
        d[el.id] = el.type === "checkbox" ? el.checked : el.value;
        try { localStorage.setItem(KEY, JSON.stringify(d)); } catch (e) {}
      };
      el.addEventListener("input", save); el.addEventListener("change", save);
    });
    const reset = document.getElementById("reset-values");
    if (reset) reset.addEventListener("click", () => {
      try { localStorage.removeItem(KEY); } catch (e) {}
      location.reload();
    });
  }

  window.OTK = { $, num, fmt, ok, on, audio, blip, piano, stepper, SHARP, FLAT, nameOf, yamahaOf, freqOf, getCtx: () => ctx, saved, T, LANG, solf };

  document.addEventListener("DOMContentLoaded", () => {
    if (!SOLF) document.body.classList.add("no-solf"); // ドレミを使わない言語では列をかくす
    remember();
    delay(); tap(); metronome(); tone(); db(); note(); transpose(); speed(); filesize(); samples(); wave();
  });
})();
